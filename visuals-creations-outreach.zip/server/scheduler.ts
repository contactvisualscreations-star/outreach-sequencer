import { db } from './db.js';
import { GmailService, AuthTokenExpiredError } from './gmail.js';
import { SchedulerRunResult } from '../src/types.js';

let isRunning = false;
let schedulerTimer: NodeJS.Timeout | null = null;

export async function processOutreachQueue(): Promise<SchedulerRunResult> {
  if (isRunning) {
    return {
      processed: 0,
      sent: 0,
      replied: 0,
      errors: [{ error: 'Scheduler run already in progress' }],
      timestamp: new Date().toISOString()
    };
  }

  isRunning = true;
  const result: SchedulerRunResult = {
    processed: 0,
    sent: 0,
    replied: 0,
    errors: [],
    timestamp: new Date().toISOString()
  };

  try {
    const sequences = db.listSequences();
    const activeSequences = sequences.filter(s => s.status === 'Active');

    for (const seq of activeSequences) {
      // 1. Check if recipient has replied (if sequence already has a Gmail thread and OAuth token is available)
      const conn = db.getConnection(seq.sender_email);
      const isAppPasswordMode = conn?.connection_mode === 'app_password' && Boolean(conn?.app_password);

      if (seq.gmail_thread_id && !isAppPasswordMode) {
        try {
          const accessToken = await GmailService.getValidAccessToken(seq.sender_email);
          const replyCheck = await GmailService.hasRecipientReplied(
            accessToken,
            seq.gmail_thread_id,
            seq.sender_email
          );

          if (replyCheck.replied) {
            console.log(`[Scheduler] Reply detected for sequence ${seq.id} (${seq.recipient}) in thread ${seq.gmail_thread_id}. Marking as Replied.`);
            db.updateSequence(seq.id, { status: 'Replied' });

            // Cancel any remaining unsent messages
            seq.messages.forEach(m => {
              if (m.status === 'Scheduled' || m.status === 'Draft') {
                db.updateMessage(m.id, { status: 'Cancelled' });
              }
            });

            result.replied++;
            continue; // Move to next sequence
          }
        } catch (err: any) {
          if (err instanceof AuthTokenExpiredError) {
            console.warn(`[Scheduler] Auth paused for ${seq.sender_email}: ${err.message}`);
            continue;
          }
          console.warn(`[Scheduler] Reply check warning for ${seq.id}:`, err.message);
        }
      }

      // 2. Sequential message evaluation: Initial (pos 1) -> Follow-up 1 (pos 2) -> Follow-up 2 (pos 3)...
      // A later message must NEVER send before prior message has successfully sent.
      const messages = [...seq.messages].sort((a, b) => a.position - b.position);
      let targetMessageToSend = null;
      let blockedByFailure = false;

      for (let i = 0; i < messages.length; i++) {
        const msg = messages[i];

        if (msg.status === 'Failed') {
          blockedByFailure = true;
          break; // Stop evaluating this sequence
        }

        if (msg.status === 'Draft' || msg.status === 'Cancelled' || msg.status === 'Skipped') {
          continue;
        }

        if (msg.status === 'Sending') {
          // Already in-flight
          blockedByFailure = true;
          break;
        }

        if (msg.status === 'Scheduled') {
          const dueTime = new Date(msg.scheduled_at_utc || msg.scheduled_at).getTime();
          const now = Date.now();

          if (dueTime <= now) {
            targetMessageToSend = msg;
          }
          break; // Only pick the earliest unsent scheduled message
        }

        // If 'Sent', continue to next position
      }

      if (blockedByFailure || !targetMessageToSend) {
        // Check if all messages are completed
        const hasUnsent = messages.some(m => m.status === 'Scheduled' || m.status === 'Draft');
        if (!hasUnsent && messages.some(m => m.status === 'Sent')) {
          db.updateSequence(seq.id, { status: 'Completed' });
        }
        continue;
      }

      // 3. Dispatch the due message via unified GmailService
      result.processed++;
      const msg = targetMessageToSend;

      try {
        db.updateMessage(msg.id, { status: 'Sending' });

        const sendRes = await GmailService.sendUnifiedMessage({
          sequenceId: seq.id,
          messageId: msg.id,
          senderEmail: seq.sender_email,
          recipient: seq.recipient,
          subject: seq.original_subject || seq.subject,
          body: msg.body,
          isFollowup: msg.position > 1
        });

        result.sent++;
        console.log(`[Scheduler] Message #${msg.position} sent for sequence ${seq.id} (Thread: ${sendRes.threadId})`);

      } catch (err: any) {
        const isAuthError = err instanceof AuthTokenExpiredError || (
          err.message && (
            err.message.includes('401') ||
            err.message.includes('Invalid Credentials') ||
            err.message.includes('UNAUTHENTICATED')
          )
        );

        if (isAuthError && !isAppPasswordMode) {
          db.markTokenExpired(seq.sender_email);
          db.updateMessage(msg.id, {
            status: 'Scheduled',
            error: 'Sender authorization expired or requires reconnect.'
          });
          console.warn(`[Scheduler] Paused sequence ${seq.id} due to expired Gmail credentials.`);
          break; // Don't attempt other sequences for this sender
        } else {
          console.error(`[Scheduler] Error sending message #${msg.position} in sequence ${seq.id}:`, err.message);
          db.updateMessage(msg.id, {
            status: 'Failed',
            error: err.message || 'Send failed'
          });
          db.updateSequence(seq.id, { status: 'Failed' });

          result.errors.push({
            sequenceId: seq.id,
            messageId: msg.id,
            error: err.message
          });
        }
      }
    }
  } catch (globalErr: any) {
    console.error('[Scheduler] Fatal error during queue run:', globalErr);
    result.errors.push({ error: globalErr.message });
  } finally {
    isRunning = false;
  }

  return result;
}

/**
 * Start the persistent internal scheduler loop
 * Runs every 15 seconds 24/7 on the server
 */
export function startScheduler() {
  if (schedulerTimer) {
    clearInterval(schedulerTimer);
  }

  console.log('[Scheduler] Background worker initialized. Running check every 15 seconds.');

  // Immediate queue check on startup
  processOutreachQueue().catch(err => console.error('[Scheduler] Startup run error:', err));

  schedulerTimer = setInterval(() => {
    processOutreachQueue().catch(err => console.error('[Scheduler] Interval run error:', err));
  }, 15 * 1000);
}
