import fs from 'fs';
import path from 'path';
import { Sequence, Message, SequenceWithMessages, GmailConnection } from '../src/types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'sequences_db.json');
const BACKUP_FILE = path.join(DATA_DIR, 'sequences_db.backup.json');

export interface DatabaseSchema {
  gmail_connections: GmailConnection[];
  sequences: Sequence[];
  messages: Message[];
  tokens?: {
    [email: string]: {
      accessToken: string;
      updatedAt: string;
      refreshToken?: string;
      expired?: boolean;
    };
  };
  lastConnectedSender?: string | null;
}

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function loadDB(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed: DatabaseSchema = JSON.parse(raw);

      if (!parsed.gmail_connections) {
        parsed.gmail_connections = [];
      }
      if (!parsed.sequences) {
        parsed.sequences = [];
      }
      if (!parsed.messages) {
        parsed.messages = [];
      }

      // Auto-migrate legacy tokens to gmail_connections if missing
      if (parsed.tokens) {
        for (const [email, tokenData] of Object.entries(parsed.tokens)) {
          const lower = email.toLowerCase().trim();
          const existing = parsed.gmail_connections.find(c => c.gmail_email.toLowerCase() === lower);
          if (!existing && tokenData.accessToken) {
            parsed.gmail_connections.push({
              id: 'conn_' + Buffer.from(lower).toString('hex').substring(0, 12),
              user_id: 'default_user',
              gmail_email: lower,
              sender_display_name: lower.split('@')[0],
              access_token: tokenData.accessToken,
              refresh_token: tokenData.refreshToken,
              granted_scopes: [
                'https://www.googleapis.com/auth/gmail.send',
                'https://www.googleapis.com/auth/gmail.modify',
                'https://www.googleapis.com/auth/gmail.readonly',
                'https://www.googleapis.com/auth/gmail.settings.basic'
              ],
              connected_at: tokenData.updatedAt || new Date().toISOString(),
              updated_at: tokenData.updatedAt || new Date().toISOString()
            });
          }
        }
      }

      return parsed;
    }
  } catch (err) {
    console.error('[DB] Error loading DB:', err);
  }

  const initial: DatabaseSchema = {
    gmail_connections: [],
    sequences: [],
    messages: [],
    tokens: {}
  };
  saveDB(initial);
  return initial;
}

function saveDB(data: DatabaseSchema) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    if (data.sequences && data.sequences.length > 0) {
      fs.writeFileSync(BACKUP_FILE, JSON.stringify(data, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('[DB] Error writing DB:', err);
  }
}

export const db = {
  // -------------------------------------------------------------
  // Gmail Connection Management (Account Independent)
  // -------------------------------------------------------------
  saveConnection(connData: Partial<GmailConnection> & { gmail_email: string; access_token: string }): GmailConnection {
    const data = loadDB();
    const lowerEmail = connData.gmail_email.toLowerCase().trim();
    const now = new Date().toISOString();

    let conn = data.gmail_connections.find(c => c.gmail_email.toLowerCase() === lowerEmail);

    if (conn) {
      // Update existing connection without losing refresh_token
      conn.access_token = connData.access_token;
      if (connData.refresh_token) {
        conn.refresh_token = connData.refresh_token;
      }
      if (connData.sender_display_name) {
        conn.sender_display_name = connData.sender_display_name;
      }
      if (connData.signature_html !== undefined) {
        conn.signature_html = connData.signature_html;
      }
      if (connData.connection_mode !== undefined) {
        conn.connection_mode = connData.connection_mode;
      }
      if (connData.app_password !== undefined) {
        conn.app_password = connData.app_password;
      }
      if (connData.oauth_client_id !== undefined) {
        conn.oauth_client_id = connData.oauth_client_id;
      }
      if (connData.oauth_client_secret !== undefined) {
        conn.oauth_client_secret = connData.oauth_client_secret;
      }
      if (connData.token_expiry) {
        conn.token_expiry = connData.token_expiry;
      }
      if (connData.granted_scopes && connData.granted_scopes.length > 0) {
        conn.granted_scopes = connData.granted_scopes;
      }
      conn.updated_at = now;
    } else {
      // Create new connection
      conn = {
        id: connData.id || 'conn_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        user_id: connData.user_id || 'default_user',
        gmail_email: lowerEmail,
        sender_display_name: connData.sender_display_name || lowerEmail.split('@')[0],
        access_token: connData.access_token || '',
        refresh_token: connData.refresh_token,
        token_expiry: connData.token_expiry,
        connection_mode: connData.connection_mode || 'oauth',
        app_password: connData.app_password,
        oauth_client_id: connData.oauth_client_id,
        oauth_client_secret: connData.oauth_client_secret,
        granted_scopes: connData.granted_scopes || [
          'https://www.googleapis.com/auth/gmail.send',
          'https://www.googleapis.com/auth/gmail.modify',
          'https://www.googleapis.com/auth/gmail.readonly',
          'https://www.googleapis.com/auth/gmail.settings.basic'
        ],
        signature_html: connData.signature_html,
        connected_at: now,
        updated_at: now
      };
      data.gmail_connections.push(conn);
    }

    // Also sync to legacy tokens object for backwards compatibility
    if (!data.tokens) data.tokens = {};
    data.tokens[lowerEmail] = {
      accessToken: conn.access_token,
      updatedAt: now,
      refreshToken: conn.refresh_token
    };
    delete (data.tokens[lowerEmail] as any).expired;
    data.lastConnectedSender = lowerEmail;

    saveDB(data);
    return conn;
  },

  getConnection(idOrEmail: string): GmailConnection | null {
    if (!idOrEmail) return null;
    const data = loadDB();
    const query = idOrEmail.toLowerCase().trim();
    return data.gmail_connections.find(c => c.id === idOrEmail || c.gmail_email.toLowerCase() === query) || null;
  },

  listConnections(): GmailConnection[] {
    const data = loadDB();
    return data.gmail_connections || [];
  },

  deleteConnection(idOrEmail: string): boolean {
    const data = loadDB();
    const query = idOrEmail.toLowerCase().trim();
    const initialLen = data.gmail_connections.length;
    data.gmail_connections = data.gmail_connections.filter(c => c.id !== idOrEmail && c.gmail_email.toLowerCase() !== query);
    if (data.tokens && data.tokens[query]) {
      delete data.tokens[query];
    }
    if (data.lastConnectedSender && data.lastConnectedSender.toLowerCase() === query) {
      data.lastConnectedSender = data.gmail_connections[0]?.gmail_email || null;
    }
    saveDB(data);
    return data.gmail_connections.length < initialLen;
  },

  // -------------------------------------------------------------
  // Legacy Token Compatibility
  // -------------------------------------------------------------
  saveToken(email: string, accessToken: string, refreshToken?: string) {
    this.saveConnection({
      gmail_email: email,
      access_token: accessToken,
      refresh_token: refreshToken
    });
  },

  markTokenExpired(email: string) {
    const data = loadDB();
    const lower = email.toLowerCase().trim();
    if (data.tokens && data.tokens[lower]) {
      (data.tokens[lower] as any).expired = true;
    }
    saveDB(data);
  },

  isTokenExpired(email: string): boolean {
    const conn = this.getConnection(email);
    if (!conn) return true;
    if (conn.token_expiry && conn.token_expiry < Date.now()) {
      // If we have a refresh_token, it's not permanently expired because we can auto-refresh it
      if (conn.refresh_token) {
        return false;
      }
      return true;
    }
    const data = loadDB();
    const entry = data.tokens?.[email.toLowerCase().trim()];
    return Boolean((entry as any)?.expired);
  },

  getToken(email: string): string | null {
    const conn = this.getConnection(email);
    return conn ? conn.access_token : null;
  },

  getLastConnectedSender(): string | null {
    const data = loadDB();
    if (data.lastConnectedSender) return data.lastConnectedSender;
    if (data.gmail_connections.length > 0) return data.gmail_connections[0].gmail_email;
    return null;
  },

  deleteToken(email: string) {
    this.deleteConnection(email);
  },

  getAllTokens(): Record<string, string> {
    const data = loadDB();
    const result: Record<string, string> = {};
    for (const c of data.gmail_connections) {
      result[c.gmail_email] = c.access_token;
    }
    return result;
  },

  // -------------------------------------------------------------
  // Sequences & Messages Management
  // -------------------------------------------------------------
  listSequences(): SequenceWithMessages[] {
    const data = loadDB();
    return data.sequences.map(seq => {
      const msgs = data.messages
        .filter(m => m.sequence_id === seq.id)
        .sort((a, b) => a.position - b.position);
      return { ...seq, messages: msgs };
    });
  },

  getSequence(id: string): SequenceWithMessages | null {
    const data = loadDB();
    const seq = data.sequences.find(s => s.id === id);
    if (!seq) return null;
    const msgs = data.messages
      .filter(m => m.sequence_id === id)
      .sort((a, b) => a.position - b.position);
    return { ...seq, messages: msgs };
  },

  createSequence(
    sequenceData: Omit<Sequence, 'id' | 'created_at' | 'updated_at'>,
    messagesData: Array<Omit<Message, 'id' | 'sequence_id' | 'created_at' | 'updated_at'>>
  ): SequenceWithMessages {
    const data = loadDB();
    const seqId = 'seq_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
    const now = new Date().toISOString();

    const connection = this.getConnection(sequenceData.sender_email);

    const newSeq: Sequence = {
      ...sequenceData,
      id: seqId,
      user_id: sequenceData.user_id || connection?.user_id || 'default_user',
      gmail_connection_id: sequenceData.gmail_connection_id || connection?.id || undefined,
      original_subject: sequenceData.original_subject || sequenceData.subject,
      created_at: now,
      updated_at: now
    };

    const newMessages: Message[] = messagesData.map((m, idx) => ({
      ...m,
      id: 'msg_' + Date.now() + '_' + idx + '_' + Math.random().toString(36).substring(2, 9),
      sequence_id: seqId,
      scheduled_at_utc: m.scheduled_at_utc || (m.scheduled_at ? new Date(m.scheduled_at).toISOString() : now),
      created_at: now,
      updated_at: now
    }));

    data.sequences.unshift(newSeq);
    data.messages.push(...newMessages);
    saveDB(data);

    return { ...newSeq, messages: newMessages };
  },

  updateSequence(id: string, updates: Partial<Sequence>): Sequence | null {
    const data = loadDB();
    const seq = data.sequences.find(s => s.id === id);
    if (!seq) return null;

    // NEVER overwrite gmail_thread_id with null or undefined once set
    if (updates.gmail_thread_id === null || updates.gmail_thread_id === undefined) {
      delete updates.gmail_thread_id;
    }

    Object.assign(seq, updates, { updated_at: new Date().toISOString() });
    saveDB(data);
    return seq;
  },

  updateMessage(id: string, updates: Partial<Message>): Message | null {
    const data = loadDB();
    const msg = data.messages.find(m => m.id === id);
    if (!msg) return null;

    if (updates.scheduled_at && !updates.scheduled_at_utc) {
      updates.scheduled_at_utc = new Date(updates.scheduled_at).toISOString();
    }

    Object.assign(msg, updates, { updated_at: new Date().toISOString() });
    saveDB(data);
    return msg;
  },

  addFollowupMessage(
    sequenceId: string,
    messageData: {
      body: string;
      scheduled_at: string;
      scheduled_at_utc?: string;
      timezone: string;
    }
  ): Message | null {
    const data = loadDB();
    const seq = data.sequences.find(s => s.id === sequenceId);
    if (!seq) return null;

    const existingMsgs = data.messages.filter(m => m.sequence_id === sequenceId);
    const maxPosition = existingMsgs.reduce((max, m) => Math.max(max, m.position), 0);
    const now = new Date().toISOString();

    const newMsg: Message = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9),
      sequence_id: sequenceId,
      position: maxPosition + 1,
      type: 'followup',
      body: messageData.body,
      scheduled_at: messageData.scheduled_at,
      scheduled_at_utc: messageData.scheduled_at_utc || new Date(messageData.scheduled_at).toISOString(),
      timezone: messageData.timezone || 'UTC',
      status: 'Scheduled',
      created_at: now,
      updated_at: now
    };

    data.messages.push(newMsg);
    seq.updated_at = now;
    saveDB(data);
    return newMsg;
  },

  deleteMessage(messageId: string): boolean {
    const data = loadDB();
    const msg = data.messages.find(m => m.id === messageId);
    if (!msg || msg.position === 1 || msg.status === 'Sent') {
      return false;
    }

    const seqId = msg.sequence_id;
    data.messages = data.messages.filter(m => m.id !== messageId);

    // Re-index remaining messages
    const remaining = data.messages
      .filter(m => m.sequence_id === seqId)
      .sort((a, b) => a.position - b.position);

    remaining.forEach((m, idx) => {
      m.position = idx + 1;
    });

    saveDB(data);
    return true;
  },

  reorderMessages(sequenceId: string, messageIds: string[]): Message[] {
    const data = loadDB();
    const seqMsgs = data.messages.filter(m => m.sequence_id === sequenceId);
    if (seqMsgs.length === 0) return [];

    const initialMsg = seqMsgs.find(m => m.position === 1);
    const followupIds = messageIds.filter(id => id !== initialMsg?.id);

    let currentPos = 2;
    for (const id of followupIds) {
      const msg = seqMsgs.find(m => m.id === id);
      if (msg && msg.position !== 1) {
        msg.position = currentPos++;
        msg.updated_at = new Date().toISOString();
      }
    }

    saveDB(data);
    return seqMsgs.sort((a, b) => a.position - b.position);
  },

  stopSequence(sequenceId: string): boolean {
    const data = loadDB();
    const seq = data.sequences.find(s => s.id === sequenceId);
    if (!seq) return false;

    const now = new Date().toISOString();
    seq.status = 'Stopped';
    seq.updated_at = now;

    // Cancel all remaining unsent messages
    data.messages.forEach(m => {
      if (m.sequence_id === sequenceId && (m.status === 'Scheduled' || m.status === 'Draft')) {
        m.status = 'Cancelled';
        m.updated_at = now;
      }
    });

    saveDB(data);
    return true;
  },

  resumeSequence(sequenceId: string): boolean {
    const data = loadDB();
    const seq = data.sequences.find(s => s.id === sequenceId);
    if (!seq) return false;

    const now = new Date().toISOString();
    seq.status = 'Active';
    seq.updated_at = now;

    data.messages.forEach(m => {
      if (m.sequence_id === sequenceId && (m.status === 'Cancelled' || m.status === 'Failed')) {
        m.status = 'Scheduled';
        m.error = null;
        m.updated_at = now;
      }
    });

    saveDB(data);
    return true;
  },

  retryAllAuthFailedSequences(): number {
    const data = loadDB();
    const now = new Date().toISOString();
    let count = 0;

    // Clear any legacy expired flags on tokens
    if (data.tokens) {
      const tokensRecord = data.tokens as Record<string, any>;
      Object.keys(tokensRecord).forEach(k => {
        if (tokensRecord[k]) {
          delete tokensRecord[k].expired;
        }
      });
    }

    data.sequences.forEach(seq => {
      const stalledMsgs = data.messages.filter(m =>
        m.sequence_id === seq.id &&
        (m.status === 'Failed' || m.status === 'Scheduled') &&
        m.error && (
          m.error.includes('401') ||
          m.error.includes('Invalid Credentials') ||
          m.error.includes('authentication') ||
          m.error.includes('UNAUTHENTICATED') ||
          m.error.includes('expired') ||
          m.error.includes('session') ||
          m.error.includes('reconnect')
        )
      );
      if (stalledMsgs.length > 0) {
        if (seq.status === 'Failed') {
          seq.status = 'Active';
          seq.updated_at = now;
        }
        stalledMsgs.forEach(m => {
          m.status = 'Scheduled';
          m.error = null;
          m.updated_at = now;
        });
        count += stalledMsgs.length;
      }
    });

    if (count > 0 || data.tokens) {
      saveDB(data);
    }
    return count;
  },

  deleteSequence(sequenceId: string): boolean {
    const data = loadDB();
    data.sequences = data.sequences.filter(s => s.id !== sequenceId);
    data.messages = data.messages.filter(m => m.sequence_id !== sequenceId);
    saveDB(data);
    return true;
  },

  restoreVault(sequencesWithMessages: SequenceWithMessages[]): { restoredCount: number; allSequences: SequenceWithMessages[] } {
    const data = loadDB();
    const existingSeqIds = new Set(data.sequences.map(s => s.id));
    const existingMsgIds = new Set(data.messages.map(m => m.id));
    let restoredCount = 0;

    for (const seqWithMsgs of sequencesWithMessages) {
      if (!existingSeqIds.has(seqWithMsgs.id)) {
        const { messages, ...seqOnly } = seqWithMsgs;
        data.sequences.unshift(seqOnly);
        existingSeqIds.add(seqWithMsgs.id);
        restoredCount++;
      }

      if (seqWithMsgs.messages && Array.isArray(seqWithMsgs.messages)) {
        for (const msg of seqWithMsgs.messages) {
          if (!existingMsgIds.has(msg.id)) {
            data.messages.push(msg);
            existingMsgIds.add(msg.id);
          }
        }
      }
    }

    if (restoredCount > 0) {
      saveDB(data);
    }

    const all = data.sequences.map(s => ({
      ...s,
      messages: data.messages.filter(m => m.sequence_id === s.id).sort((a, b) => a.position - b.position)
    }));

    return { restoredCount, allSequences: all };
  }
};
