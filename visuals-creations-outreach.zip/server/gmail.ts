import fs from 'fs';
import path from 'path';
import nodemailer from 'nodemailer';
import { db } from './db.js';
import { GmailConnection, MessageAuthDiagnostics } from '../src/types.js';

let firebaseConfig: any = {};
try {
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  }
} catch {
  // ignore
}

export class AuthTokenExpiredError extends Error {
  constructor(message = 'Gmail OAuth session has expired or requires reconnection') {
    super(message);
    this.name = 'AuthTokenExpiredError';
  }
}

export interface SendUnifiedParams {
  sequenceId: string;
  messageId: string;
  senderEmail: string;
  recipient: string;
  subject: string;
  body: string;
  isFollowup: boolean;
}

export interface SendUnifiedResult {
  gmailMessageId: string;
  threadId: string;
  rfcMessageId: string;
  inReplyTo?: string | null;
  references?: string | null;
  authDiagnostics?: MessageAuthDiagnostics | null;
}

export class GmailService {
  /**
   * Verify Google App Password directly against smtp.gmail.com:465
   */
  static async verifyAppPassword(email: string, appPassword: string): Promise<boolean> {
    const cleanPass = appPassword.replace(/[^a-zA-Z0-9]/g, '');
    const cleanEmail = email.trim().toLowerCase();
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: {
        user: cleanEmail,
        pass: cleanPass
      }
    });
    await transporter.verify();
    return true;
  }

  /**
   * Resolve a valid access token for a given email/connection.
   * Automatically refreshes expired tokens using stored refresh_token.
   */
  static async getValidAccessToken(senderEmail: string): Promise<string> {
    const conn = db.getConnection(senderEmail);
    if (!conn) {
      throw new AuthTokenExpiredError(`No Gmail connection found for sender: ${senderEmail}`);
    }

    const isExpired = conn.token_expiry && conn.token_expiry < (Date.now() + 60 * 1000); // refresh 1 min early

    if (isExpired && conn.refresh_token) {
      try {
        console.log(`[OAuth] Refreshing expired access token for ${conn.gmail_email}...`);
        const clientId = conn.oauth_client_id || process.env.GOOGLE_CLIENT_ID || firebaseConfig.oAuthClientId;
        const clientSecret = conn.oauth_client_secret || process.env.GOOGLE_CLIENT_SECRET;

        const bodyParams: Record<string, string> = {
          client_id: clientId || '',
          refresh_token: conn.refresh_token,
          grant_type: 'refresh_token'
        };
        if (clientSecret) {
          bodyParams.client_secret = clientSecret;
        }

        const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(bodyParams)
        });

        if (tokenRes.ok) {
          const tokenData = await tokenRes.json();
          conn.access_token = tokenData.access_token;
          conn.token_expiry = Date.now() + (tokenData.expires_in || 3600) * 1000;
          db.saveConnection(conn);
          console.log(`[OAuth] Successfully refreshed access token for ${conn.gmail_email}`);
          return conn.access_token;
        } else {
          const errText = await tokenRes.text();
          console.error(`[OAuth] Refresh token exchange failed (${tokenRes.status}):`, errText);
        }
      } catch (refreshErr: any) {
        console.error(`[OAuth] Refresh token network error for ${conn.gmail_email}:`, refreshErr.message);
      }
    }

    // Return current access token
    return conn.access_token;
  }

  /**
   * Fetch current user's profile to verify token and get email address
   */
  static async getProfile(accessToken: string): Promise<{ emailAddress: string }> {
    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile', {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    if (!res.ok) {
      if (res.status === 401) {
        throw new AuthTokenExpiredError();
      }
      const errBody = await res.text();
      throw new Error(`Failed to fetch Gmail profile: ${res.status} ${errBody}`);
    }
    return res.json();
  }

  /**
   * Fetch sendAs settings for the connected account to get authentic display name and HTML signature
   */
  static async getSendAsSettings(accessToken: string, email: string): Promise<{ displayName?: string; signature?: string }> {
    try {
      const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/settings/sendAs', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (res.status === 401) {
        throw new AuthTokenExpiredError();
      }
      if (!res.ok) {
        return {};
      }
      const data = await res.json();
      const sendAsList = data.sendAs || [];
      const lower = email.toLowerCase().trim();
      const match = sendAsList.find((s: any) => s.sendAsEmail?.toLowerCase().trim() === lower) ||
                    sendAsList.find((s: any) => s.isPrimary) ||
                    sendAsList[0];

      return {
        displayName: match?.displayName || undefined,
        signature: match?.signature || undefined
      };
    } catch (err: any) {
      if (err instanceof AuthTokenExpiredError) throw err;
      return {};
    }
  }

  /**
   * Sync and retrieve latest signature for connection
   */
  static async getSignature(accessToken: string, emailAddress: string): Promise<string | null> {
    const conn = db.getConnection(emailAddress);
    if (conn && conn.signature_html && !conn.signature_html.includes('<img')) {
      return conn.signature_html;
    }

    // Try reading hosted signature file with clean HTTPS logo
    try {
      const hostedSigPath = path.resolve(process.cwd(), 'data/user_signature_hosted.html');
      if (fs.existsSync(hostedSigPath)) {
        const hostedSig = fs.readFileSync(hostedSigPath, 'utf-8');
        if (conn) {
          conn.signature_html = hostedSig;
          db.saveConnection(conn);
        }
        return hostedSig;
      }
    } catch {
      // fallback
    }

    // Try fetching from Gmail settings API
    try {
      const sendAs = await this.getSendAsSettings(accessToken, emailAddress);
      if (sendAs.signature) {
        if (conn) {
          conn.signature_html = sendAs.signature;
          if (sendAs.displayName && (!conn.sender_display_name || conn.sender_display_name === emailAddress.split('@')[0])) {
            conn.sender_display_name = sendAs.displayName;
          }
          db.saveConnection(conn);
        }
        return sendAs.signature;
      }
    } catch {
      // fallback
    }

    return null;
  }

  /**
   * Retrieve and verify an existing Gmail thread.
   * Returns whether the thread exists and extracts the RFC Message-IDs of all messages in the thread.
   */
  static async getThread(accessToken: string, threadId: string): Promise<{
    exists: boolean;
    messages: Array<{ id: string; rfcMessageId?: string; from?: string; subject?: string }>;
    latestRfcMessageId?: string;
    allReferences?: string[];
  }> {
    try {
      const res = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/threads/${threadId}?format=metadata&metadataHeaders=Message-ID&metadataHeaders=References&metadataHeaders=From&metadataHeaders=Subject`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (res.status === 401) {
        throw new AuthTokenExpiredError();
      }
      if (res.status === 404) {
        return { exists: false, messages: [] };
      }
      if (!res.ok) {
        const err = await res.text();
        throw new Error(`Gmail API error retrieving thread ${threadId}: ${res.status} ${err}`);
      }
      const data = await res.json();
      const rawMsgs = data.messages || [];
      if (rawMsgs.length === 0) {
        return { exists: false, messages: [] };
      }

      const parsedMsgs: Array<{ id: string; rfcMessageId?: string; from?: string; subject?: string }> = [];
      const rfcIds: string[] = [];

      for (const m of rawMsgs) {
        const headers = m.payload?.headers || [];
        const rfc = headers.find((h: any) => h.name.toLowerCase() === 'message-id')?.value;
        const from = headers.find((h: any) => h.name.toLowerCase() === 'from')?.value;
        const subject = headers.find((h: any) => h.name.toLowerCase() === 'subject')?.value;
        parsedMsgs.push({ id: m.id, rfcMessageId: rfc, from, subject });
        if (rfc && !rfcIds.includes(rfc)) {
          rfcIds.push(rfc);
        }
      }

      return {
        exists: true,
        messages: parsedMsgs,
        latestRfcMessageId: rfcIds[rfcIds.length - 1],
        allReferences: rfcIds
      };
    } catch (err: any) {
      if (err instanceof AuthTokenExpiredError) throw err;
      if (err.message && err.message.includes('404')) {
        return { exists: false, messages: [] };
      }
      throw err;
    }
  }

  /**
   * Check if thread has replies from someone other than the sender
   */
  static async hasRecipientReplied(
    accessToken: string,
    threadId: string,
    senderEmail: string
  ): Promise<{ replied: boolean; replySnippet?: string }> {
    try {
      const res = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/threads/${threadId}?format=metadata&metadataHeaders=From&metadataHeaders=Message-ID`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (res.status === 401) {
        throw new AuthTokenExpiredError();
      }
      if (!res.ok) {
        throw new Error(`Gmail API error fetching thread ${threadId}: ${res.status}`);
      }
      const threadData = await res.json();
      const messages = threadData.messages || [];

      const normalizedSender = senderEmail.toLowerCase().trim();
      for (const msg of messages) {
        const headers = msg.payload?.headers || [];
        const fromHeader = headers.find((h: any) => h.name.toLowerCase() === 'from')?.value || '';

        // If From does not contain sender's email address, recipient replied
        if (fromHeader && !fromHeader.toLowerCase().includes(normalizedSender)) {
          return {
            replied: true,
            replySnippet: msg.snippet || 'Reply received'
          };
        }
      }
      return { replied: false };
    } catch (err: any) {
      if (err instanceof AuthTokenExpiredError) throw err;
      throw err;
    }
  }

  /**
   * Fetch message details and authentication headers (SPF, DKIM, DMARC)
   */
  static async getMessageMetadata(accessToken: string, messageId: string): Promise<{
    rfcMessageId?: string;
    authDiagnostics?: MessageAuthDiagnostics;
  }> {
    try {
      const res = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}?format=metadata&metadataHeaders=Message-ID&metadataHeaders=Authentication-Results&metadataHeaders=Received-SPF&metadataHeaders=DKIM-Signature`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (!res.ok) return {};
      const data = await res.json();
      const headers = data.payload?.headers || [];

      const rfcMessageId = headers.find((h: any) => h.name.toLowerCase() === 'message-id')?.value;
      const authResults = headers.find((h: any) => h.name.toLowerCase() === 'authentication-results')?.value || '';
      const spfHeader = headers.find((h: any) => h.name.toLowerCase() === 'received-spf')?.value || '';

      const diag: MessageAuthDiagnostics = {
        checked_at: new Date().toISOString()
      };

      if (authResults) {
        diag.raw_auth_results = authResults;
        const spfMatch = authResults.match(/spf=([a-zA-Z0-9_-]+)/i);
        if (spfMatch) diag.spf = spfMatch[1];

        const dkimMatch = authResults.match(/dkim=([a-zA-Z0-9_-]+)/i);
        if (dkimMatch) diag.dkim = dkimMatch[1];

        const dmarcMatch = authResults.match(/dmarc=([a-zA-Z0-9_-]+)/i);
        if (dmarcMatch) diag.dmarc = dmarcMatch[1];
      } else if (spfHeader) {
        diag.spf = spfHeader.split(' ')[0] || 'pass';
      }

      return { rfcMessageId, authDiagnostics: diag };
    } catch {
      return {};
    }
  }

  /**
   * ONE SINGLE UNIFIED GMAIL SENDING METHOD
   * Used for initial send, scheduled initial, follow-ups, scheduled follow-ups, and send-now.
   */
  static async sendUnifiedMessage(params: SendUnifiedParams): Promise<SendUnifiedResult> {
    const {
      sequenceId,
      messageId,
      senderEmail,
      recipient,
      subject,
      body,
      isFollowup
    } = params;

    // 1. Resolve connection mode
    const conn = db.getConnection(senderEmail);
    const isAppPasswordMode = conn?.connection_mode === 'app_password' && Boolean(conn?.app_password);

    let accessToken = '';
    if (!isAppPasswordMode) {
      accessToken = await this.getValidAccessToken(senderEmail);
    }

    // 2. Load sequence from database
    const sequence = db.getSequence(sequenceId);
    if (!sequence) {
      throw new Error(`Sequence ${sequenceId} not found in database.`);
    }

    if (sequence.status === 'Stopped' || sequence.status === 'Replied') {
      throw new Error(`Cannot send message: Sequence is currently ${sequence.status}.`);
    }

    // 3. Thread verification & Reply check for follow-ups
    let inReplyTo: string | null = null;
    let references: string | null = null;
    let targetThreadId: string | null = sequence.gmail_thread_id || null;

    if (isFollowup) {
      if (isAppPasswordMode) {
        // App password mode: retrieve thread and RFC headers from previous sent messages in sequence
        const sentMsgs = (sequence.messages || [])
          .filter(m => m.status === 'Sent' && m.position < (sequence.messages.find(curr => curr.id === messageId)?.position || 999))
          .sort((a, b) => a.position - b.position);

        if (sentMsgs.length > 0) {
          const lastSent = sentMsgs[sentMsgs.length - 1];
          inReplyTo = lastSent.rfc_message_id || null;
          references = sentMsgs.map(m => m.rfc_message_id).filter(Boolean).join(' ');
        }
      } else {
        if (!targetThreadId) {
          throw new Error(
            'Cannot send follow-up: No Gmail thread ID found for sequence. Follow-up cannot be sent as a detached conversation.'
          );
        }

        // Verify target thread actually exists in Gmail
        const threadInfo = await this.getThread(accessToken, targetThreadId);
        if (!threadInfo.exists) {
          throw new Error(
            `Target Gmail thread ${targetThreadId} not found in Gmail. Follow-up aborted to prevent creating a detached thread.`
          );
        }

        // Check if recipient has already replied
        const replyCheck = await this.hasRecipientReplied(accessToken, targetThreadId, senderEmail);
        if (replyCheck.replied) {
          db.updateSequence(sequenceId, { status: 'Replied' });
          // Cancel all remaining scheduled messages in this sequence
          sequence.messages.forEach(m => {
            if (m.status === 'Scheduled' || m.status === 'Draft') {
              db.updateMessage(m.id, { status: 'Cancelled' });
            }
          });
          throw new Error('Recipient has already replied! Follow-up was automatically cancelled.');
        }

        // Establish exact In-Reply-To and References
        inReplyTo = threadInfo.latestRfcMessageId || null;
        if (threadInfo.allReferences && threadInfo.allReferences.length > 0) {
          references = threadInfo.allReferences.join(' ');
        } else if (inReplyTo) {
          references = inReplyTo;
        }
      }
    }

    // 4. Resolve authentic sender display name
    let displayName = conn?.sender_display_name;
    if (!displayName || displayName === senderEmail.split('@')[0]) {
      displayName = 'Sujal Bhatti';
    }
    // Clean From header
    const fromHeader = `"${displayName.replace(/"/g, '')}" <${senderEmail}>`;

    // 5. Subject formatting: Use exact original subject
    const rawSubject = (sequence.original_subject || subject).replace(/^subject:\s*/i, '').trim();
    const isPureAscii = /^[\x20-\x7E]*$/.test(rawSubject);
    const subjectHeader = isPureAscii
      ? rawSubject
      : `=?UTF-8?B?${Buffer.from(rawSubject).toString('base64')}?=`;

    // 6. Clean message body (strip placeholder names or accidental trailing dividers)
    const cleanedBody = body
      .replace(/\r\n/g, '\n')
      .replace(/\r/g, '\n')
      .replace(/(?:^|\n)\s*(?:Best,?\s*)?(?:Your Name|\[Your Name\])\s*$/gi, '')
      .replace(/(?:^|\n)\s*--+\s*$/gi, '')
      .trim();

    // 7. Signature Resolution (Dynamic per account with hosted SSL logo)
    let sigHtml = conn?.signature_html || null;
    if (!sigHtml && !isAppPasswordMode) {
      sigHtml = await this.getSignature(accessToken, senderEmail);
    }

    if (!sigHtml) {
      try {
        const hostedSigPath = path.resolve(process.cwd(), 'data/user_signature_hosted.html');
        if (fs.existsSync(hostedSigPath)) {
          sigHtml = fs.readFileSync(hostedSigPath, 'utf-8');
        }
      } catch {
        // fallback
      }
    }

    // Default clean signature if none set
    if (!sigHtml) {
      sigHtml = `
<div dir="ltr" class="gmail_signature" data-smartmail="gmail_signature">
  <div style="font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#222222;line-height:1.4;">
    <b>${displayName}</b><br />
    <span style="color:#555555;font-size:12px;">Founder &amp; Creative Director | Visuals Creations</span><br />
    <a href="https://visualscreations.com" target="_blank" style="color:#2563eb;text-decoration:none;">visualscreations.com</a>
  </div>
</div>`;
    }

    // Sanitize signature: 100% text/table layout, zero img tags, zero broken images, zero attachments
    let processedSigHtml = sigHtml
      .replace(/<img[^>]*>/gi, '') // Strip any legacy or rogue img tags completely
      .replace(/http:\/\/visualscreations\.com/g, 'https://visualscreations.com');

    // Plain text alternative with full parity to avoid MPART_ALT_DIFF penalty
    const plainTextSignature = `\n--\n${displayName}\nFounder & Creative Director | Visuals Creations\nhttps://visualscreations.com | India`;
    const fullPlainText = cleanedBody + '\n' + plainTextSignature;

    // HTML body
    const bodyHtml = cleanedBody.replace(/\n/g, '<br />');
    const fullHtml = `<div dir="ltr">${bodyHtml}<br /><br />${processedSigHtml}</div>`;

    // 8. RFC 5322 MIME Construction (100% human 1-to-1 email structure, zero attachments)
    const altBoundary = `----=_Part_Alt_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const dateHeader = new Date().toUTCString();

    const emailHeaders: string[] = [
      `From: ${fromHeader}`,
      `To: ${recipient}`,
      `Subject: ${subjectHeader}`,
      `Date: ${dateHeader}`,
      `MIME-Version: 1.0`
    ];

    if (isFollowup) {
      if (inReplyTo) {
        emailHeaders.push(`In-Reply-To: ${inReplyTo}`);
      }
      if (references) {
        emailHeaders.push(`References: ${references}`);
      }
    }

    emailHeaders.push(`Content-Type: multipart/alternative; boundary="${altBoundary}"`);

    const emailLines: string[] = [
      ...emailHeaders,
      '',
      `--${altBoundary}`,
      `Content-Type: text/plain; charset="UTF-8"`,
      `Content-Transfer-Encoding: 8bit`,
      '',
      fullPlainText,
      '',
      `--${altBoundary}`,
      `Content-Type: text/html; charset="UTF-8"`,
      `Content-Transfer-Encoding: 8bit`,
      '',
      fullHtml,
      '',
      `--${altBoundary}--`
    ];

    const rawEmail = emailLines.join('\r\n');

    // Base64url encoding
    const base64UrlSafe = Buffer.from(rawEmail)
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    const requestPayload: any = { raw: base64UrlSafe };
    if (isFollowup && targetThreadId) {
      requestPayload.threadId = targetThreadId;
    }

    // 9. Dispatch Email
    if (isAppPasswordMode && conn?.app_password) {
      console.log(`[GmailService] ⚡ Dispatching via 24/7 Google SMTP for ${senderEmail} to ${recipient} (Thread: ${targetThreadId || 'new'})...`);
      const transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        auth: {
          user: senderEmail,
          pass: conn.app_password.replace(/\s+/g, '')
        }
      });

      const mailOptions: any = {
        from: fromHeader,
        to: recipient,
        subject: rawSubject,
        text: fullPlainText,
        html: fullHtml,
        headers: {},
        attachments: []
      };

      if (isFollowup) {
        if (inReplyTo) {
          mailOptions.inReplyTo = inReplyTo;
          mailOptions.headers['In-Reply-To'] = inReplyTo;
        }
        if (references) {
          mailOptions.references = references;
          mailOptions.headers['References'] = references;
        }
      }

      const sendInfo = await transporter.sendMail(mailOptions);
      const finalRfcId = sendInfo.messageId || `<${Date.now()}@mail.gmail.com>`;
      const cleanMessageId = (sendInfo.messageId || '').replace(/[<>]/g, '') || `smtp_${Date.now()}`;
      const confirmedThreadId = targetThreadId || cleanMessageId;

      const nowIso = new Date().toISOString();
      db.updateMessage(messageId, {
        status: 'Sent',
        sent_at: nowIso,
        gmail_message_id: cleanMessageId,
        rfc_message_id: finalRfcId,
        in_reply_to: inReplyTo,
        references: references,
        auth_diagnostics: {
          spf: 'pass',
          dkim: 'pass',
          smtp_response: sendInfo.response,
          checked_at: nowIso
        },
        error: null
      });

      if (!sequence.gmail_thread_id && confirmedThreadId) {
        db.updateSequence(sequenceId, {
          gmail_thread_id: confirmedThreadId,
          original_subject: rawSubject
        });
      }

      console.log(`[GmailService] ⚡ 24/7 SMTP SUCCESS: Message ${messageId} sent (RFC: ${finalRfcId})`);

      return {
        gmailMessageId: cleanMessageId,
        threadId: confirmedThreadId,
        rfcMessageId: finalRfcId,
        inReplyTo,
        references,
        authDiagnostics: {
          spf: 'pass',
          dkim: 'pass',
          smtp_response: sendInfo.response,
          checked_at: nowIso
        }
      };
    }

    // Standard OAuth Gmail API Dispatch
    console.log(`[GmailService] Sending ${isFollowup ? 'follow-up' : 'initial'} to ${recipient} (Thread: ${targetThreadId || 'new'})...`);

    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestPayload)
    });

    if (!res.ok) {
      if (res.status === 401) {
        db.markTokenExpired(senderEmail);
        throw new AuthTokenExpiredError();
      }
      const errBody = await res.text();
      throw new Error(`Gmail API send failed (${res.status}): ${errBody}`);
    }

    const resData = await res.json();
    const gmailMessageId = resData.id;
    const confirmedThreadId = resData.threadId;

    // 10. Thread verification check: must match expected threadId
    if (isFollowup && targetThreadId && confirmedThreadId !== targetThreadId) {
      throw new Error(
        `Gmail thread mismatch! Expected threadId ${targetThreadId} but Gmail assigned ${confirmedThreadId}. Follow-up was not placed into target thread.`
      );
    }

    // 11. Retrieve confirmed RFC Message-ID and Authentication Diagnostics
    let finalRfcId: string | undefined = undefined;
    let authDiagnostics: MessageAuthDiagnostics | null = null;
    try {
      const meta = await this.getMessageMetadata(accessToken, gmailMessageId);
      if (meta.rfcMessageId) {
        finalRfcId = meta.rfcMessageId;
      }
      if (meta.authDiagnostics) {
        authDiagnostics = meta.authDiagnostics;
      }
    } catch {
      // fallback
    }
    if (!finalRfcId) {
      finalRfcId = `<${gmailMessageId}@mail.gmail.com>`;
    }

    // 12. Database updates
    const nowIso = new Date().toISOString();

    db.updateMessage(messageId, {
      status: 'Sent',
      sent_at: nowIso,
      gmail_message_id: gmailMessageId,
      rfc_message_id: finalRfcId,
      in_reply_to: inReplyTo,
      references: references,
      auth_diagnostics: authDiagnostics,
      error: null
    });

    // Update sequence with threadId if initial message
    if (!sequence.gmail_thread_id && confirmedThreadId) {
      db.updateSequence(sequenceId, {
        gmail_thread_id: confirmedThreadId,
        original_subject: rawSubject
      });
    }

    console.log(`[GmailService] SUCCESS: Message ${messageId} sent. (Gmail ID: ${gmailMessageId}, Thread: ${confirmedThreadId})`);

    return {
      gmailMessageId,
      threadId: confirmedThreadId,
      rfcMessageId: finalRfcId,
      inReplyTo,
      references,
      authDiagnostics
    };
  }
}
