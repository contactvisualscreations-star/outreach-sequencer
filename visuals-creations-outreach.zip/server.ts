import express from 'express';
import path from 'path';
import { db } from './server/db.ts';
import { GmailService, AuthTokenExpiredError } from './server/gmail.ts';
import { processOutreachQueue, startScheduler } from './server/scheduler.ts';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Serve static assets publicly
app.use(express.static(path.resolve(process.cwd(), 'public')));
app.use('/assets', express.static(path.resolve(process.cwd(), 'public')));

// -------------------------------------------------------------
// Helper to extract Bearer token from authorization header
// -------------------------------------------------------------
function extractBearerToken(req: express.Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  return null;
}

// -------------------------------------------------------------
// API Routes: Gmail Authentication & Connections
// -------------------------------------------------------------

// Sync user's Gmail connection to server database (Connect once with offline persistence)
app.post('/api/auth/sync-token', async (req, res) => {
  try {
    const headerToken = extractBearerToken(req);
    const { email, accessToken, refreshToken, displayName } = req.body;
    const token = accessToken || headerToken;

    if (!token || !email) {
      return res.status(400).json({ error: 'Token and email are required' });
    }

    let confirmedEmail = email.toLowerCase().trim();
    let verifiedDisplayName = displayName;

    try {
      // Verify token with Gmail profile API
      const profile = await GmailService.getProfile(token);
      if (profile.emailAddress) {
        confirmedEmail = profile.emailAddress.toLowerCase().trim();
      }
    } catch (profileErr: any) {
      console.warn('Gmail profile verification warning:', profileErr.message);
      const errMsg = profileErr.message || '';
      if (errMsg.includes('403') || errMsg.includes('SERVICE_DISABLED') || errMsg.includes('has not been used')) {
        return res.status(403).json({
          error: profileErr.message,
          code: 'GMAIL_API_DISABLED_OR_RESTRICTED',
          message: 'The Gmail API returned 403 Forbidden. Either Gmail API is not enabled in the Cloud project, or this user does not have permission.'
        });
      }
      throw profileErr;
    }

    // Try fetching authentic sendAs display name and HTML signature from Gmail settings
    let signatureHtml: string | undefined = undefined;
    try {
      const sendAs = await GmailService.getSendAsSettings(token, confirmedEmail);
      if (sendAs.displayName) {
        verifiedDisplayName = sendAs.displayName;
      }
      if (sendAs.signature) {
        signatureHtml = sendAs.signature;
      }
    } catch {
      // ignore
    }

    // Save connection permanently in database
    const savedConn = db.saveConnection({
      gmail_email: confirmedEmail,
      sender_display_name: verifiedDisplayName || confirmedEmail.split('@')[0],
      access_token: token,
      refresh_token: refreshToken,
      signature_html: signatureHtml,
      token_expiry: Date.now() + 3600 * 1000 // 1 hour validity
    });

    // Auto-resume any sequences that were stalled due to expired OAuth tokens
    const resumedCount = db.retryAllAuthFailedSequences();
    if (resumedCount > 0) {
      console.log(`[Auth Sync] Auto-resumed ${resumedCount} sequences after token renewal.`);
    }

    // Trigger immediate background scheduler check
    processOutreachQueue().catch((e: any) => console.warn('Scheduler check error:', e));

    return res.json({
      success: true,
      connectionId: savedConn.id,
      email: confirmedEmail,
      displayName: savedConn.sender_display_name,
      resumedSequences: resumedCount
    });
  } catch (err: any) {
    console.error('Error in /api/auth/sync-token:', err);
    return res.status(err.status || 401).json({ error: err.message || 'Invalid Gmail credentials' });
  }
});

// Check currently connected sender session (stored on server DB)
app.get('/api/auth/session', async (req, res) => {
  try {
    const lastSender = db.getLastConnectedSender();
    if (!lastSender) {
      return res.json({ connected: false });
    }

    const conn = db.getConnection(lastSender);
    if (!conn) {
      return res.json({ connected: false, email: lastSender });
    }

    const isAppPassword = conn.connection_mode === 'app_password' && Boolean(conn.app_password);
    let isValid = isAppPassword;
    let validToken = conn.access_token;

    if (!isAppPassword) {
      try {
        validToken = await GmailService.getValidAccessToken(conn.gmail_email);
        const profile = await GmailService.getProfile(validToken);
        if (profile && profile.emailAddress) {
          isValid = true;
        }
      } catch {
        isValid = false;
      }
    }

    const signature = await GmailService.getSignature(validToken, conn.gmail_email);

    return res.json({
      connected: true,
      email: conn.gmail_email,
      displayName: conn.sender_display_name,
      token: validToken || conn.access_token,
      active: isValid,
      needsRefresh: !isValid && !isAppPassword,
      expired: false,
      connectionMode: conn.connection_mode || 'oauth',
      is247Offline: isAppPassword,
      signature
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Connect Google App Password for 24/7 background offline dispatch (works when device is off)
app.post('/api/sender/connect-app-password', async (req, res) => {
  try {
    const { email, appPassword, displayName } = req.body;
    if (!email || !appPassword) {
      return res.status(400).json({ error: 'Gmail address and 16-character App Password are required' });
    }

    const cleanPass = appPassword.replace(/[^a-zA-Z0-9]/g, '');
    const cleanEmail = email.toLowerCase().trim();
    if (cleanPass.length !== 16) {
      return res.status(400).json({
        error: `Google App Passwords must be exactly 16 letters (you entered ${cleanPass.length}). Please copy the 16-character code from https://myaccount.google.com/apppasswords.`
      });
    }

    console.log(`[AppPassword] Verifying 24/7 Google SMTP for ${cleanEmail}...`);
    await GmailService.verifyAppPassword(cleanEmail, cleanPass);

    const savedConn = db.saveConnection({
      gmail_email: cleanEmail,
      access_token: '',
      sender_display_name: displayName || cleanEmail.split('@')[0],
      connection_mode: 'app_password',
      app_password: cleanPass
    });

    const resumedCount = db.retryAllAuthFailedSequences();
    processOutreachQueue().catch((e: any) => console.warn('Scheduler check error:', e));

    return res.json({
      success: true,
      email: savedConn.gmail_email,
      displayName: savedConn.sender_display_name,
      connectionMode: 'app_password',
      is247Offline: true,
      resumedSequences: resumedCount,
      message: '24/7 Offline Sending Engine activated. Your scheduled emails will now dispatch on time even when your computer is off!'
    });
  } catch (err: any) {
    console.error('[AppPassword] Verification failed:', err.message);
    const errText = err.message || '';
    if (errText.includes('535') || errText.includes('Username and Password not accepted')) {
      return res.status(400).json({
        error: `Google rejected credentials (535 Invalid Credentials). The 16-character App Password must match the exact Google account you are signed into. If you generated it while signed into "rishab83602@gmail.com", set the email to rishab83602@gmail.com. If you want to send from "contactvisualscreations@gmail.com", you must generate the password while signed into contactvisualscreations@gmail.com!`
      });
    }
    return res.status(400).json({
      error: `Google rejected credentials (${err.message}). Ensure 2-Step Verification is turned ON and create an App Password at https://myaccount.google.com/apppasswords.`
    });
  }
});

// List all connected accounts
app.get('/api/connections', (req, res) => {
  try {
    const connections = db.listConnections().map(c => ({
      id: c.id,
      email: c.gmail_email,
      displayName: c.sender_display_name,
      connectedAt: c.connected_at,
      hasRefreshToken: Boolean(c.refresh_token)
    }));
    return res.json(connections);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Delete / disconnect connection
app.delete('/api/connections/:idOrEmail', (req, res) => {
  try {
    const success = db.deleteConnection(req.params.idOrEmail);
    return res.json({ success });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Logout sender
app.post('/api/auth/logout', (req, res) => {
  const { email } = req.body;
  if (email) {
    db.deleteConnection(email);
  }
  return res.json({ success: true });
});

// Check current connected sender info & signature
app.get('/api/sender/info', async (req, res) => {
  try {
    const token = extractBearerToken(req);
    let email = db.getLastConnectedSender();
    let currentToken = token;

    if (token) {
      const profile = await GmailService.getProfile(token);
      email = profile.emailAddress;
    } else if (email) {
      const conn = db.getConnection(email);
      if (conn?.connection_mode === 'app_password' && conn?.app_password) {
        return res.json({
          email: conn.gmail_email,
          displayName: conn.sender_display_name || conn.gmail_email.split('@')[0],
          connectionMode: 'app_password',
          is247Offline: true,
          signature: conn.signature_html || null
        });
      }
      currentToken = await GmailService.getValidAccessToken(email);
    }

    if (!email || !currentToken) {
      return res.status(401).json({ error: 'No connected Gmail account found' });
    }

    const signature = await GmailService.getSignature(currentToken, email);
    const conn = db.getConnection(email);

    return res.json({
      email,
      displayName: conn?.sender_display_name || email.split('@')[0],
      signature: signature || null
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// API Routes: Sequences & Messages
// -------------------------------------------------------------

// List all sequences
app.get('/api/sequences', (req, res) => {
  try {
    const sequences = db.listSequences();
    return res.json(sequences);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Get single sequence
app.get('/api/sequences/:id', async (req, res) => {
  try {
    const seq = db.getSequence(req.params.id);
    if (!seq) {
      return res.status(404).json({ error: 'Sequence not found' });
    }
    const conn = db.getConnection(seq.sender_email);
    let signature: string | null | undefined = conn?.signature_html;
    if (!signature) {
      signature = await GmailService.getSignature('', seq.sender_email);
    }
    return res.json({ ...seq, signature_html: signature || undefined });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Create new sequence (Manual or Auto import)
app.post('/api/sequences', async (req, res) => {
  try {
    const token = extractBearerToken(req);
    const { sequence, messages } = req.body;

    if (!sequence || !messages || !messages.length) {
      return res.status(400).json({ error: 'Sequence and at least 1 message required' });
    }

    // Save token if passed in header
    if (token && sequence.sender_email) {
      db.saveConnection({
        gmail_email: sequence.sender_email,
        access_token: token
      });
    }

    const created = db.createSequence(sequence, messages);

    // If initial message is scheduled for NOW (or within 15 seconds), send immediately via unified service
    const firstMsg = created.messages[0];
    const isDueNow = firstMsg && (
      firstMsg.status === 'Draft' || firstMsg.status === 'Scheduled'
    ) && (
      !firstMsg.scheduled_at || new Date(firstMsg.scheduled_at).getTime() <= Date.now() + 15000
    );

    if (isDueNow) {
      try {
        db.updateMessage(firstMsg.id, { status: 'Sending' });
        const sendResult = await GmailService.sendUnifiedMessage({
          sequenceId: created.id,
          messageId: firstMsg.id,
          senderEmail: created.sender_email,
          recipient: created.recipient,
          subject: created.original_subject || created.subject,
          body: firstMsg.body,
          isFollowup: false
        });

        // Refresh sequence object with threadId
        const updatedSeq = db.getSequence(created.id);
        return res.json(updatedSeq || created);
      } catch (sendErr: any) {
        console.error('[Create Sequence] Immediate send failed:', sendErr.message);
        db.updateMessage(firstMsg.id, {
          status: 'Failed',
          error: sendErr.message
        });
        db.updateSequence(created.id, { status: 'Failed' });
        return res.json(db.getSequence(created.id) || created);
      }
    }

    return res.json(created);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Batch create multiple sequences at once (e.g. from pasted multi-lead list)
app.post('/api/sequences/batch', async (req, res) => {
  try {
    const token = extractBearerToken(req);
    const { items } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Array of items required' });
    }

    const createdList = [];
    for (const item of items) {
      const { sequence, messages } = item;
      if (!sequence || !messages || !messages.length) continue;

      if (token && sequence.sender_email) {
        db.saveConnection({
          gmail_email: sequence.sender_email,
          access_token: token
        });
      }

      const created = db.createSequence(sequence, messages);
      createdList.push(created);
    }

    return res.json({ success: true, count: createdList.length, sequences: createdList });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Restore sequences from browser vault (Prevents any data elimination when container reboots)
app.post('/api/sequences/restore-vault', (req, res) => {
  try {
    const { sequences } = req.body;
    if (!sequences || !Array.isArray(sequences)) {
      return res.status(400).json({ error: 'Array of sequences required' });
    }
    const result = db.restoreVault(sequences);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Add follow-up to sequence
app.post('/api/sequences/:id/messages', (req, res) => {
  try {
    const { body, scheduled_at, timezone } = req.body;
    if (!body || !scheduled_at) {
      return res.status(400).json({ error: 'Body and scheduled_at are required' });
    }
    const newMsg = db.addFollowupMessage(req.params.id, {
      body,
      scheduled_at,
      timezone: timezone || 'UTC'
    });
    if (!newMsg) {
      return res.status(404).json({ error: 'Sequence not found' });
    }
    return res.json(newMsg);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Edit message
app.patch('/api/messages/:id', (req, res) => {
  try {
    const updated = db.updateMessage(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Message not found' });
    }
    return res.json(updated);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Reorder messages for a sequence
app.post('/api/sequences/:id/reorder', (req, res) => {
  try {
    const { message_ids } = req.body;
    if (!Array.isArray(message_ids)) {
      return res.status(400).json({ error: 'message_ids array required' });
    }
    const updated = db.reorderMessages(req.params.id, message_ids);
    return res.json(updated);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Delete follow-up message
app.delete('/api/messages/:id', (req, res) => {
  try {
    const success = db.deleteMessage(req.params.id);
    if (!success) {
      return res.status(400).json({ error: 'Cannot delete message (either sent or initial message)' });
    }
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Skip a message
app.post('/api/messages/:id/skip', (req, res) => {
  try {
    const updated = db.updateMessage(req.params.id, { status: 'Skipped' });
    if (!updated) {
      return res.status(404).json({ error: 'Message not found' });
    }
    return res.json(updated);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Send message NOW (Immediate dispatch using unified Gmail sending architecture)
app.post('/api/messages/:id/send-now', async (req, res) => {
  try {
    const token = extractBearerToken(req);
    const seqs = db.listSequences();
    let targetMsg = null;
    let targetSeq = null;

    for (const s of seqs) {
      const found = s.messages.find(m => m.id === req.params.id);
      if (found) {
        targetMsg = found;
        targetSeq = s;
        break;
      }
    }

    if (!targetMsg || !targetSeq) {
      return res.status(404).json({ error: 'Message not found' });
    }

    if (token) {
      db.saveConnection({
        gmail_email: targetSeq.sender_email,
        access_token: token
      });
    }

    // Must not be Stopped or Replied
    if (targetSeq.status === 'Stopped' || targetSeq.status === 'Replied') {
      return res.status(400).json({ error: `Cannot send: Sequence is ${targetSeq.status}` });
    }

    // If sequence was in Failed state, restore it to Active so it can proceed
    if (targetSeq.status === 'Failed') {
      db.updateSequence(targetSeq.id, { status: 'Active' });
    }

    // Check sequencing order: all earlier messages must be Sent or Skipped
    const priorUnsent = targetSeq.messages.filter(
      m => m.position < targetMsg!.position && m.status !== 'Sent' && m.status !== 'Skipped'
    );
    if (priorUnsent.length > 0) {
      return res.status(400).json({
        error: `Cannot send: Previous message #${priorUnsent[0].position} must be sent or skipped first`
      });
    }

    db.updateMessage(targetMsg.id, { status: 'Sending' });

    // Dispatch via ONE single unified GmailService method
    const sendResult = await GmailService.sendUnifiedMessage({
      sequenceId: targetSeq.id,
      messageId: targetMsg.id,
      senderEmail: targetSeq.sender_email,
      recipient: targetSeq.recipient,
      subject: targetSeq.original_subject || targetSeq.subject,
      body: targetMsg.body,
      isFollowup: targetMsg.position > 1
    });

    const updatedSeq = db.getSequence(targetSeq.id);
    const updatedMsg = updatedSeq?.messages.find(m => m.id === targetMsg!.id);
    return res.json(updatedMsg || sendResult);

  } catch (err: any) {
    console.error(`[Send Now] Error sending message ${req.params.id}:`, err.message);
    db.updateMessage(req.params.id, {
      status: 'Failed',
      error: err.message
    });
    return res.status(500).json({ error: err.message });
  }
});

// Stop Sequence
app.post('/api/sequences/:id/stop', (req, res) => {
  try {
    const success = db.stopSequence(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'Sequence not found' });
    }
    const updated = db.getSequence(req.params.id);
    return res.json(updated);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Resume / Retry Sequence
app.post('/api/sequences/:id/resume', (req, res) => {
  try {
    const success = db.resumeSequence(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'Sequence not found' });
    }
    const updated = db.getSequence(req.params.id);
    return res.json(updated);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Delete Sequence
app.delete('/api/sequences/:id', (req, res) => {
  try {
    const success = db.deleteSequence(req.params.id);
    return res.json({ success });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Trigger scheduler manually / via Cloud Scheduler / cron-job.org Webhook
let lastSchedulerTick: { time: string; source?: string; isCronJobOrg?: boolean; result: any } | null = null;

const handleTick = async (req: express.Request, res: express.Response) => {
  try {
    const userAgent = req.headers['user-agent'] || 'direct';
    const isCronJobOrg = userAgent.includes('cron-job.org');
    const sourceLabel = isCronJobOrg ? 'cron-job.org' : (userAgent.substring(0, 40));

    console.log(`[Scheduler Tick] External heartbeat received at ${new Date().toISOString()} via ${sourceLabel}`);

    const result = await processOutreachQueue();
    lastSchedulerTick = {
      time: new Date().toISOString(),
      source: sourceLabel,
      isCronJobOrg,
      result
    };
    return res.json({
      success: true,
      message: 'Outreach queue tick processed successfully',
      source: sourceLabel,
      result
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
};

app.post('/api/scheduler/tick', handleTick);
app.get('/api/scheduler/tick', handleTick);

// Get scheduler status & stats
app.get('/api/scheduler/status', (req, res) => {
  const sequences = db.listSequences();
  const allMessages = sequences.flatMap(s => s.messages);

  const stats = {
    activeSequences: sequences.filter(s => s.status === 'Active').length,
    repliedSequences: sequences.filter(s => s.status === 'Replied').length,
    stoppedSequences: sequences.filter(s => s.status === 'Stopped').length,
    completedSequences: sequences.filter(s => s.status === 'Completed').length,
    scheduledMessages: allMessages.filter(m => m.status === 'Scheduled').length,
    sentMessages: allMessages.filter(m => m.status === 'Sent').length,
    failedMessages: allMessages.filter(m => m.status === 'Failed').length,
    connectionsStored: db.listConnections().length,
    lastTick: lastSchedulerTick,
    appUrl: process.env.APP_URL || ''
  };

  return res.json(stats);
});

// -------------------------------------------------------------
// Vite middleware for development or static dist in production
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
    // Start persistent background scheduler
    startScheduler();
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
