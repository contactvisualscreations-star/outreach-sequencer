import React, { useState, useEffect } from 'react';
import { SequenceWithMessages, SequenceStatus } from '../types';
import { Plus, Search, Filter, Mail, CheckCircle, Clock, AlertTriangle, Play, RefreshCw, Send, ShieldCheck, LogOut, ChevronRight, Zap, Key, ExternalLink, Lock, Database, Download, Upload } from 'lucide-react';
import { googleSignIn, logout, requestSilentTokenRefresh } from '../auth';
import { syncVaultWithServer, exportVaultToFile, saveSequencesToVault } from '../utils/vault';
import { startBackgroundScheduler } from '../utils/backgroundWorker';

interface Props {
  onCreateClick: () => void;
  onSelectSequence: (id: string) => void;
  userEmail: string | null;
  tokenExpired?: boolean;
  onAuthChange: (email: string | null, expired?: boolean) => void;
}

export const Dashboard: React.FC<Props> = ({ onCreateClick, onSelectSequence, userEmail, tokenExpired, onAuthChange }) => {
  const [sequences, setSequences] = useState<SequenceWithMessages[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [marketFilter, setMarketFilter] = useState<string>('All');
  const [triggeringWorker, setTriggeringWorker] = useState(false);
  const [workerResult, setWorkerResult] = useState<any>(null);

  const fetchSequences = async () => {
    try {
      setLoading(true);
      const [seqRes, statsRes, sessionRes] = await Promise.all([
        fetch('/api/sequences'),
        fetch('/api/scheduler/status'),
        fetch('/api/auth/session')
      ]);

      if (seqRes.ok) {
        const seqData = await seqRes.json();
        // Automatically sync and safeguard with persistent browser vault
        const synced = await syncVaultWithServer(seqData);
        setSequences(synced);
      }
      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }
      if (sessionRes.ok) {
        const sessionData = await sessionRes.json();
        if (sessionData.signature) {
          setSignatureHtml(sessionData.signature);
        }
        if (sessionData.is247Offline) {
          setIs247Offline(true);
        }
      }
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleImportBackupFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const synced = await syncVaultWithServer(parsed);
          setSequences(synced);
          saveSequencesToVault(synced);
          alert(`Successfully restored ${parsed.length} sequences to your vault and server!`);
        } else {
          alert('Invalid backup format. Expected an array of sequences.');
        }
      } catch (err: any) {
        alert('Failed to parse backup file: ' + err.message);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  useEffect(() => {
    // 1. Immediately trigger queue check on mount
    fetch('/api/scheduler/tick').catch(() => {});
    fetchSequences();

    // 2. Start unthrottled Web Worker ticker for continuous background execution even when minimized
    const stopWorker = startBackgroundScheduler(() => {
      fetch('/api/scheduler/tick').catch(() => {});
      fetchSequences();
    }, 15000);

    return () => stopWorker();
  }, []);

  const [authErrorModalOpen, setAuthErrorModalOpen] = useState(false);
  const [authErrorMessage, setAuthErrorMessage] = useState('');
  const [signatureHtml, setSignatureHtml] = useState<string | null>(null);
  const [showSignatureModal, setShowSignatureModal] = useState(false);

  // 24/7 Offline Sending Engine State (Device Off Mode)
  const [is247Offline, setIs247Offline] = useState(false);
  const [show247Modal, setShow247Modal] = useState(false);
  const [appPasswordInput, setAppPasswordInput] = useState('');
  const [appPasswordEmail, setAppPasswordEmail] = useState('');
  const [appPasswordLoading, setAppPasswordLoading] = useState(false);
  const [appPasswordError, setAppPasswordError] = useState<string | null>(null);
  const [appPasswordSuccess, setAppPasswordSuccess] = useState<string | null>(null);

  const handleSaveAppPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAppPasswordError(null);
    setAppPasswordSuccess(null);
    setAppPasswordLoading(true);

    try {
      const email = (appPasswordEmail || userEmail || '').trim();
      const res = await fetch('/api/sender/connect-app-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          appPassword: appPasswordInput
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to verify Google App Password');
      }

      setAppPasswordSuccess(data.message || '24/7 Offline Sending Mode is now active!');
      setIs247Offline(true);
      onAuthChange(email, false);
      setTimeout(() => {
        setShow247Modal(false);
        setAppPasswordSuccess(null);
        setAppPasswordInput('');
      }, 1500);
      fetchSequences();
    } catch (err: any) {
      setAppPasswordError(err.message);
    } finally {
      setAppPasswordLoading(false);
    }
  };

  const handleConnectGmail = async (options?: { switchAccount?: boolean; targetEmail?: string }) => {
    try {
      const res = await googleSignIn(options);
      if (res?.email) {
        onAuthChange(res.email, false);
        fetchSequences();
      }
    } catch (err: any) {
      console.error('Sign in failed:', err);
      setAuthErrorMessage(err.message || 'Access blocked or cancelled');
      setAuthErrorModalOpen(true);
    }
  };

  const handleDisconnect = async () => {
    await logout();
    onAuthChange(null, false);
  };

  const handleTriggerSchedulerTick = async () => {
    try {
      setTriggeringWorker(true);
      const res = await fetch('/api/scheduler/tick', { method: 'POST' });
      const data = await res.json();
      setWorkerResult(data.result);
      await fetchSequences();
      setTimeout(() => setWorkerResult(null), 5000);
    } catch (err: any) {
      alert('Error triggering scheduler: ' + err.message);
    } finally {
      setTriggeringWorker(false);
    }
  };

  // Filtered list
  const markets = Array.from(new Set(sequences.map(s => s.market).filter(Boolean)));

  const filteredSequences = sequences.filter(s => {
    const matchesSearch = 
      s.recipient.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.category || '').toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'All' || s.status === statusFilter;
    const matchesMarket = marketFilter === 'All' || s.market === marketFilter;

    return matchesSearch && matchesStatus && matchesMarket;
  });

  const getNextAction = (seq: SequenceWithMessages) => {
    if (seq.status === 'Replied') return 'Sequence Finished (Replied)';
    if (seq.status === 'Stopped') return 'Sequence Stopped';
    if (seq.status === 'Completed') return 'All messages sent';
    if (seq.status === 'Failed') return 'Paused: Click to Resume / Retry';

    const nextScheduled = seq.messages.find(m => m.status === 'Scheduled');
    if (nextScheduled) {
      const isDue = new Date(nextScheduled.scheduled_at).getTime() <= Date.now();
      if (isDue) return `Due now: ${nextScheduled.type === 'initial' ? 'Initial Email' : `Follow-up #${nextScheduled.position - 1}`}`;
      return `${nextScheduled.type === 'initial' ? 'Initial Email' : `Follow-up #${nextScheduled.position - 1}`} at ${new Date(nextScheduled.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
    return 'None';
  };

  const getLastActivity = (seq: SequenceWithMessages) => {
    const sentMsgs = seq.messages.filter(m => m.status === 'Sent');
    if (sentMsgs.length > 0) {
      const last = sentMsgs[sentMsgs.length - 1];
      return `Sent #${last.position} (${last.sent_at ? new Date(last.sent_at).toLocaleDateString() : ''})`;
    }
    return `Created ${new Date(seq.created_at).toLocaleDateString()}`;
  };

  const statusBadge = (status: SequenceStatus) => {
    switch (status) {
      case 'Active':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Active</span>;
      case 'Replied':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">Replied</span>;
      case 'Stopped':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">Stopped</span>;
      case 'Completed':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">Completed</span>;
      case 'Failed':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">Failed</span>;
    }
  };

  const handleQuickRenew = async () => {
    try {
      const refreshed = await requestSilentTokenRefresh(userEmail || undefined);
      if (refreshed) {
        onAuthChange(userEmail, false);
      } else {
        handleConnectGmail({ switchAccount: false, targetEmail: userEmail || undefined });
      }
    } catch {
      handleConnectGmail({ switchAccount: false, targetEmail: userEmail || undefined });
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Session Expired Banner - only if explicit user action needed */}
      {tokenExpired && (
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-blue-200 text-xs shadow-lg">
          <div className="flex items-center gap-2.5">
            <RefreshCw className="w-5 h-5 text-blue-400 shrink-0" />
            <div>
              <p className="font-semibold text-blue-100">
                Active Gmail Session for <span className="font-mono text-white">{userEmail || 'Connected Account'}</span>
              </p>
              <p className="text-slate-400 text-[11px] mt-0.5">
                Google access token ready. Click to re-sync active background token if needed.
              </p>
            </div>
          </div>
          <button
            onClick={handleQuickRenew}
            className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow transition shrink-0 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Sync Session
          </button>
        </div>
      )}

      {/* Top Bar / Sender Auth Status */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Mail className="w-6 h-6 text-blue-500" /> Gmail Same-Thread Sequencer
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Automated outreach sequences & same-thread follow-ups running via persistent server scheduler.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Permanent Sender Pill */}
          <div className="flex items-center gap-2 bg-slate-950 p-2 pl-3 rounded-lg border border-slate-800 text-xs shadow-inner">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${is247Offline ? 'bg-emerald-400 animate-pulse' : 'bg-blue-400 animate-pulse'}`} />
              <span className="text-slate-400">Sender:</span>
              <strong className="text-white font-mono">{userEmail || 'No account connected'}</strong>
              <span className={`text-[10px] px-1.5 py-0.5 rounded border font-medium ${
                !userEmail
                  ? 'text-slate-400 bg-slate-800 border-slate-700'
                  : is247Offline
                  ? 'text-emerald-300 bg-emerald-500/20 border-emerald-500/40 font-semibold'
                  : 'text-blue-300 bg-blue-500/10 border-blue-500/20'
              }`}>
                {!userEmail ? 'Not Connected' : is247Offline ? '⚡ 24/7 Offline Ready (Device Off)' : 'Web Session'}
              </span>
            </div>

            <div className="flex items-center gap-1 border-l border-slate-800 pl-2 ml-1">
              {!is247Offline && (
                <button
                  onClick={() => {
                    setAppPasswordEmail(userEmail || '');
                    setShow247Modal(true);
                  }}
                  className="px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] transition cursor-pointer flex items-center gap-1 shadow"
                  title="Enable 24/7 background sending so emails dispatch even when your computer is off"
                >
                  ⚡ Enable 24/7 (Device Off)
                </button>
              )}
              {is247Offline && (
                <button
                  onClick={() => {
                    setAppPasswordEmail(userEmail || '');
                    setShow247Modal(true);
                  }}
                  className="px-2 py-0.5 rounded bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/30 text-[10px] transition cursor-pointer flex items-center gap-1"
                  title="24/7 Background Sending is active"
                >
                  ⚡ 24/7 Settings
                </button>
              )}
              <button
                onClick={handleQuickRenew}
                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-[10px] transition cursor-pointer flex items-center gap-1"
                title="Sync or refresh Gmail token"
              >
                <RefreshCw className="w-2.5 h-2.5 text-blue-400" /> Sync
              </button>
              <button
                onClick={() => setShowSignatureModal(true)}
                className="text-slate-400 hover:text-white px-2 py-1 rounded hover:bg-slate-800 text-[11px] transition cursor-pointer flex items-center gap-1"
                title="Preview Gmail Signature (Auto-Attached with CID images)"
              >
                Signature
              </button>
              <button
                onClick={() => handleConnectGmail({ switchAccount: true })}
                className="text-slate-400 hover:text-white px-2 py-1 rounded hover:bg-slate-800 text-[11px] transition cursor-pointer"
                title="Switch to another Google Account"
              >
                Switch
              </button>
              <button
                onClick={handleDisconnect}
                className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-rose-500/10 transition cursor-pointer"
                title="Disconnect Account"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <button
            onClick={onCreateClick}
            className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-lg shadow-blue-600/20 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" /> New Sequence
          </button>
        </div>
      </div>

      {/* Scheduler Summary & Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div 
          onClick={() => setStatusFilter('All')}
          className={`bg-slate-900 border rounded-xl p-4 cursor-pointer transition ${statusFilter === 'All' ? 'border-blue-500 shadow-lg shadow-blue-500/10 ring-1 ring-blue-500/30' : 'border-slate-800 hover:border-slate-700'}`}
        >
          <div className="text-xs text-slate-400 font-medium">All Sequences</div>
          <div className="text-2xl font-bold text-white mt-1">
            {sequences.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Click to view all ({sequences.length})</div>
        </div>

        <div 
          onClick={() => setStatusFilter('Active')}
          className={`bg-slate-900 border rounded-xl p-4 cursor-pointer transition ${statusFilter === 'Active' ? 'border-emerald-500 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500/30' : 'border-slate-800 hover:border-slate-700'}`}
        >
          <div className="text-xs text-slate-400 font-medium">Active (In-Progress)</div>
          <div className="text-2xl font-bold text-emerald-400 mt-1">
            {stats?.activeSequences ?? sequences.filter(s => s.status === 'Active').length}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Awaiting next follow-up</div>
        </div>

        <div 
          onClick={() => setStatusFilter('Completed')}
          className={`bg-slate-900 border rounded-xl p-4 cursor-pointer transition ${statusFilter === 'Completed' ? 'border-blue-500 shadow-lg shadow-blue-500/10 ring-1 ring-blue-500/30' : 'border-slate-800 hover:border-slate-700'}`}
        >
          <div className="text-xs text-slate-400 font-medium">Completed Sequences</div>
          <div className="text-2xl font-bold text-blue-400 mt-1">
            {sequences.filter(s => s.status === 'Completed').length}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">All emails sent ({sequences.filter(s => s.status === 'Completed').length})</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Total Messages Sent</div>
          <div className="text-2xl font-bold text-slate-200 mt-1">
            {stats?.sentMessages ?? sequences.flatMap(s => s.messages).filter(m => m.status === 'Sent').length}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Delivered via Gmail</div>
        </div>
      </div>

      {/* Server Scheduler Status Bar */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex flex-col sm:flex-row sm:items-center gap-2 text-slate-300">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>24/7 Cloud Background Worker: <strong className="text-emerald-400">Online & Armed</strong></span>
          </div>
          {stats?.lastTick?.time && (
            <span className="text-[11px] text-slate-300 border-l sm:pl-2 border-slate-700 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              Cron Heartbeat: <strong className="text-emerald-300">{new Date(stats.lastTick.time).toLocaleTimeString()}</strong>
              {stats.lastTick.source && (
                <span className="text-slate-400 font-mono text-[10px]">({stats.lastTick.source})</span>
              )}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {workerResult && (
            <span className="text-emerald-400 text-xs font-mono">
              Worker ran: {workerResult.sent} sent, {workerResult.replied} replied
            </span>
          )}
          <button
            onClick={handleTriggerSchedulerTick}
            disabled={triggeringWorker}
            className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center gap-1.5 transition font-medium"
          >
            <Play className={`w-3.5 h-3.5 ${triggeringWorker ? 'animate-spin' : ''}`} />
            Run Worker Now
          </button>
        </div>
      </div>

      {/* Device-Off Persistence Vault Bar */}
      <div className="bg-emerald-950/30 border border-emerald-500/20 rounded-lg p-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5 text-emerald-300">
          <Database className="w-4 h-4 text-emerald-400 shrink-0" />
          <div>
            <span className="font-semibold text-emerald-200">Anti-Erase Data Vault: </span>
            <span className="text-emerald-400/90 text-[11px]">
              {sequences.length} sequences secured. Automatically preserved and re-synced even if you turn off your system or reload the app.
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => exportVaultToFile(sequences)}
            className="px-2.5 py-1.5 rounded bg-emerald-900/40 hover:bg-emerald-900/70 border border-emerald-500/30 text-emerald-200 flex items-center gap-1.5 transition text-[11px] font-medium cursor-pointer"
            title="Download JSON backup"
          >
            <Download className="w-3.5 h-3.5" /> Export Backup
          </button>
          <label className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 flex items-center gap-1.5 transition text-[11px] font-medium cursor-pointer">
            <Upload className="w-3.5 h-3.5" /> Restore Backup
            <input
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleImportBackupFile}
            />
          </label>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search recipient, subject, category..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Status:</span>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-xs rounded-lg px-3 py-2 text-white focus:outline-none"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Replied">Replied</option>
              <option value="Stopped">Stopped</option>
              <option value="Completed">Completed</option>
              <option value="Failed">Failed</option>
            </select>
          </div>

          {markets.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Market:</span>
              <select
                value={marketFilter}
                onChange={e => setMarketFilter(e.target.value)}
                className="bg-slate-900 border border-slate-800 text-xs rounded-lg px-3 py-2 text-white focus:outline-none"
              >
                <option value="All">All Markets</option>
                {markets.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
          )}

          <button
            onClick={fetchSequences}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white"
            title="Refresh list"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Sequences Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        {loading && sequences.length === 0 ? (
          <div className="text-center py-16 text-slate-400 text-sm">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-blue-500" />
            Loading sequences...
          </div>
        ) : filteredSequences.length === 0 ? (
          <div className="text-center py-16 text-slate-400 text-sm">
            <Mail className="w-10 h-10 mx-auto mb-3 text-slate-600" />
            <p className="font-medium text-slate-300">No outreach sequences found</p>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Create your first sequence using Manual Follow-up or Paste Import.
            </p>
            {userEmail && (
              <button
                onClick={onCreateClick}
                className="mt-4 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs inline-flex items-center gap-1.5 transition"
              >
                <Plus className="w-4 h-4" /> Create Sequence
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase font-semibold">
                  <th className="py-3 px-4">Recipient & Subject</th>
                  <th className="py-3 px-4">Market / Category</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Progress</th>
                  <th className="py-3 px-4">Next Action</th>
                  <th className="py-3 px-4">Last Activity</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredSequences.map(seq => {
                  const sentCount = seq.messages.filter(m => m.status === 'Sent').length;
                  const totalCount = seq.messages.length;
                  const progressPct = totalCount > 0 ? Math.round((sentCount / totalCount) * 100) : 0;

                  return (
                    <tr
                      key={seq.id}
                      onClick={() => onSelectSequence(seq.id)}
                      className="hover:bg-slate-800/50 cursor-pointer transition"
                    >
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-white truncate max-w-xs">{seq.subject}</div>
                        <div className="text-slate-400 font-mono text-[11px] truncate max-w-xs mt-0.5">{seq.recipient}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="text-slate-200">{seq.market || '—'}</div>
                        <div className="text-slate-400 text-[11px]">{seq.category || '—'}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        {statusBadge(seq.status)}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="bg-blue-500 h-full rounded-full transition-all"
                              style={{ width: `${progressPct}%` }}
                            />
                          </div>
                          <span className="text-slate-300 text-[11px] font-mono">
                            {sentCount}/{totalCount}
                          </span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {getNextAction(seq)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-400">
                        {getLastActivity(seq)}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <span className="text-blue-400 font-medium inline-flex items-center gap-1 hover:underline">
                          View <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Auth Error / Test User Guidance Modal */}
      {authErrorModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-lg w-full shadow-2xl text-left">
            <div className="flex items-center gap-3 text-rose-400 mb-3">
              <AlertTriangle className="w-6 h-6 flex-shrink-0" />
              <h3 className="text-base font-bold text-white">Google OAuth: Access Blocked (Error 403)</h3>
            </div>
            
            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Google blocks sensitive scopes (like Gmail) while an OAuth app is in <strong>Testing mode</strong> unless the signing-in Google account is registered as an approved <strong>Test user</strong> in Google Cloud Console.
            </p>

            <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 text-xs text-slate-300 mb-4 space-y-2">
              <div className="font-semibold text-blue-400">Step 1: Enable Gmail API</div>
              <p className="text-slate-400">
                Ensure Gmail API is turned ON: Go to <a href="https://console.cloud.google.com/apis/library/gmail.googleapis.com" target="_blank" rel="noreferrer" className="text-blue-400 underline">Gmail API in Google Cloud Console</a> and click <strong>Enable</strong> for project <code className="text-slate-200 bg-slate-900 px-1 py-0.5 rounded">ai-studio-applet-webapp-7ee78</code>.
              </p>

              <div className="font-semibold text-blue-400 pt-2 border-t border-slate-800">Step 2: Add Account as Test User</div>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-400">
                <li>Go to <a href="https://console.cloud.google.com/apis/credentials/consent" target="_blank" rel="noreferrer" className="text-blue-400 underline">Google Cloud Console &gt; OAuth consent screen</a></li>
                <li>Scroll down to the <strong>Test users</strong> section</li>
                <li>Click <strong>+ ADD USERS</strong> and add your sending Gmail address (and any other sending account)</li>
                <li>Click <strong>Save</strong> and retry clicking "Connect Gmail Account"</li>
              </ol>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setAuthErrorModalOpen(false)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Gmail Signature Preview Modal */}
      {showSignatureModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  Sender Signature: {userEmail || 'Connected Gmail Account'}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Synchronized from Gmail account settings and auto-attached to outreach emails.
                </p>
              </div>
              <button
                onClick={() => setShowSignatureModal(false)}
                className="text-slate-400 hover:text-white text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700"
              >
                ✕ Close
              </button>
            </div>

            <div className="mb-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong>Executive Typographic Signature (100% Client Compatibility):</strong>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Designed specifically for cold outreach. Zero image dependencies, zero broken image placeholders, zero attachment flags. Perfectly balanced and rendered natively across iCloud, Gmail, Outlook, and mobile.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg p-5 text-slate-900 overflow-x-auto shadow-inner border border-slate-200">
              {signatureHtml ? (
                <div dangerouslySetInnerHTML={{ __html: signatureHtml }} />
              ) : (
                <div className="text-slate-500 text-sm text-center py-6">
                  Loading HTML signature from Gmail account...
                </div>
              )}
            </div>

            <div className="mt-4 flex items-center justify-between">
              <span className="text-[11px] text-slate-400 font-mono">
                Visuals Creations • Verified Template
              </span>
              <button
                onClick={() => setShowSignatureModal(false)}
                className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow transition"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 24/7 Offline Background Sending Modal (Works when device is off) */}
      {show247Modal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-lg w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    24/7 Offline Sending Engine
                  </h3>
                  <p className="text-xs text-slate-400">
                    Emails dispatch on time even when your computer is completely turned off.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShow247Modal(false);
                  setAppPasswordError(null);
                  setAppPasswordSuccess(null);
                }}
                className="text-slate-400 hover:text-white text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 cursor-pointer"
              >
                ✕ Close
              </button>
            </div>

            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3.5 mb-4 text-xs text-emerald-200 space-y-1">
              <div className="font-semibold text-emerald-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5" /> Why This Is Needed:
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Standard Google OAuth web tokens expire after 60 minutes when your browser tab is closed. A dedicated <strong>Google App Password</strong> gives the cloud server permanent authorization to dispatch your Day 2, Day 5, and Day 10 follow-ups on schedule 24/7, <strong>with zero session timeouts even if your laptop is powered off</strong>.
              </p>
            </div>

            {/* Quick Setup Guide */}
            <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-3.5 mb-4 text-xs space-y-2 text-slate-300">
              <div className="font-semibold text-blue-400 flex items-center justify-between">
                <span>Setup Guide:</span>
                <a
                  href="https://myaccount.google.com/apppasswords"
                  target="_blank"
                  rel="noreferrer"
                  className="text-blue-400 hover:text-blue-300 underline flex items-center gap-1 text-[11px]"
                >
                  Open App Passwords <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Fix for "The setting that you are looking for is not available" */}
              <div className="p-2.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-200 text-[11px]">
                <strong>Seeing "The setting that you are looking for is not available"?</strong>
                <p className="text-slate-300 mt-0.5">
                  Google disables this page until <strong>2-Step Verification</strong> is enabled. Click below to turn it ON first:
                </p>
                <a
                  href="https://myaccount.google.com/signinoptions/two-step-verification"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-amber-300 hover:text-white underline font-semibold mt-1"
                >
                  👉 Step 1: Turn ON 2-Step Verification Here <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-400 pt-1">
                <li>Turn ON 2-Step Verification via the link above.</li>
                <li>Go to <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noreferrer" className="text-blue-400 underline">myaccount.google.com/apppasswords</a></li>
                <li>Type the app name <strong>"Sequencer"</strong> and click <strong>Create</strong>.</li>
                <li>Copy the yellow 16-character code (e.g. <code className="bg-slate-900 px-1 py-0.5 rounded text-amber-300 font-mono">abcd efgh ijkl mnop</code>) and paste below.</li>
              </ol>
            </div>

            {appPasswordError && (
              <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                {appPasswordError}
              </div>
            )}

            {appPasswordSuccess && (
              <div className="mb-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                {appPasswordSuccess}
              </div>
            )}

            <form onSubmit={handleSaveAppPassword} className="space-y-3.5">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-slate-300">
                    Your Sending Gmail Address
                  </label>
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <button
                      type="button"
                      onClick={() => setAppPasswordEmail('contactvisualscreations@gmail.com')}
                      className="text-blue-400 hover:text-blue-300 underline cursor-pointer"
                    >
                      contactvisualscreations@gmail.com
                    </button>
                    <span className="text-slate-600">|</span>
                    <button
                      type="button"
                      onClick={() => setAppPasswordEmail('rishab83602@gmail.com')}
                      className="text-blue-400 hover:text-blue-300 underline cursor-pointer"
                    >
                      rishab83602@gmail.com
                    </button>
                  </div>
                </div>
                <input
                  type="email"
                  required
                  value={appPasswordEmail}
                  onChange={(e) => setAppPasswordEmail(e.target.value)}
                  placeholder="contactvisualscreations@gmail.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                />
                <p className="text-[10px] text-amber-300/80 mt-1">
                  ⚠️ Crucial: The App Password only works for the exact Google account that created it.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1 flex items-center justify-between">
                  <span>16-Character Google App Password</span>
                  <span className="text-[10px] text-slate-500">Spaces are stripped automatically</span>
                </label>
                <div className="relative">
                  <Key className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={appPasswordInput}
                    onChange={(e) => setAppPasswordInput(e.target.value)}
                    placeholder="abcd efgh ijkl mnop"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 font-mono tracking-wider"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setShow247Modal(false)}
                  className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={appPasswordLoading}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {appPasswordLoading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Verifying with Google...
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5" /> Activate 24/7 Offline Sending
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
