import React, { useState } from 'react';
import { SequenceWithMessages, Message } from '../types';
import { ArrowLeft, Send, SkipForward, Trash2, Edit3, StopCircle, RefreshCw, CheckCircle, AlertCircle, Clock, Check, Play, RotateCcw } from 'lucide-react';
import { authenticatedFetch } from '../auth';

interface Props {
  sequenceId: string;
  onBack: () => void;
  onRefresh: () => void;
}

export const SequenceDetail: React.FC<Props> = ({ sequenceId, onBack, onRefresh }) => {
  const [sequence, setSequence] = useState<SequenceWithMessages | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // New follow-up state
  const [showAddModal, setShowAddModal] = useState(false);
  const [newBody, setNewBody] = useState('');
  const [newDate, setNewDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().split('T')[0];
  });
  const [newTime, setNewTime] = useState('10:00');
  const [newTz, setNewTz] = useState('America/New_York');

  // Edit message state
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editBody, setEditBody] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editTime, setEditTime] = useState('');

  const fetchSequence = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/sequences/${sequenceId}`);
      if (!res.ok) throw new Error('Failed to load sequence');
      const data = await res.json();
      setSequence(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchSequence();
  }, [sequenceId]);

  const handleStopSequence = async () => {
    if (!window.confirm('Are you sure you want to stop this sequence? All unsent follow-ups will be cancelled.')) return;
    try {
      setActionLoading('stop');
      const res = await fetch(`/api/sequences/${sequenceId}/stop`, { method: 'POST' });
      if (!res.ok) throw new Error('Failed to stop sequence');
      await fetchSequence();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleResumeSequence = async () => {
    try {
      setActionLoading('resume');
      const res = await fetch(`/api/sequences/${sequenceId}/resume`, { method: 'POST' });
      if (!res.ok) throw new Error('Failed to resume sequence');
      await fetchSequence();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleSendNow = async (messageId: string) => {
    try {
      setActionLoading(messageId);
      const res = await authenticatedFetch(`/api/messages/${messageId}/send-now`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send message');
      await fetchSequence();
      onRefresh();
    } catch (err: any) {
      alert(`Send failed: ${err.message}`);
      await fetchSequence();
    } finally {
      setActionLoading(null);
    }
  };

  const handleSkip = async (messageId: string) => {
    try {
      setActionLoading(messageId);
      const res = await fetch(`/api/messages/${messageId}/skip`, { method: 'POST' });
      if (!res.ok) throw new Error('Failed to skip message');
      await fetchSequence();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!window.confirm('Are you sure you want to delete this unsent follow-up?')) return;
    try {
      setActionLoading(messageId);
      const res = await fetch(`/api/messages/${messageId}`, { method: 'DELETE' });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to delete');
      }
      await fetchSequence();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleSaveEdit = async (messageId: string) => {
    try {
      setActionLoading(messageId);
      const sched = new Date(`${editDate}T${editTime}:00`).toISOString();
      const res = await fetch(`/api/messages/${messageId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          body: editBody,
          scheduled_at: sched
        })
      });
      if (!res.ok) throw new Error('Failed to update message');
      setEditingMessageId(null);
      await fetchSequence();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleAddFollowup = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setActionLoading('add');
      const sched = new Date(`${newDate}T${newTime}:00`).toISOString();
      const res = await fetch(`/api/sequences/${sequenceId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          body: newBody,
          scheduled_at: sched,
          timezone: newTz
        })
      });
      if (!res.ok) throw new Error('Failed to add follow-up');
      setShowAddModal(false);
      setNewBody('');
      await fetchSequence();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleMove = async (currentIndex: number, direction: 'up' | 'down') => {
    if (!sequence) return;
    const items = [...sequence.messages];
    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    // Initial message at position 0 cannot be moved
    if (targetIndex < 1 || targetIndex >= items.length) return;

    const temp = items[currentIndex];
    items[currentIndex] = items[targetIndex];
    items[targetIndex] = temp;

    const messageIds = items.map(m => m.id);
    try {
      const res = await fetch(`/api/sequences/${sequenceId}/reorder`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message_ids: messageIds })
      });
      if (!res.ok) throw new Error('Failed to reorder');
      await fetchSequence();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-slate-400">
        <RefreshCw className="w-6 h-6 animate-spin mr-2" /> Loading sequence details...
      </div>
    );
  }

  if (error || !sequence) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <button onClick={onBack} className="text-slate-400 hover:text-white flex items-center gap-2 mb-4 text-sm">
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
        <div className="bg-rose-500/10 border border-rose-500/30 text-rose-400 p-4 rounded-lg">
          {error || 'Sequence not found'}
        </div>
      </div>
    );
  }

  const statusColors: Record<string, string> = {
    Active: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    Replied: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30',
    Stopped: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    Completed: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    Failed: 'bg-rose-500/10 text-rose-400 border-rose-500/30'
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-white text-sm font-medium transition"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Sequences
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchSequence}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
            title="Refresh"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          {sequence.status === 'Active' && (
            <button
              onClick={handleStopSequence}
              disabled={actionLoading === 'stop'}
              className="px-4 py-2 rounded-lg bg-rose-600/10 hover:bg-rose-600/20 text-rose-400 border border-rose-600/30 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
            >
              <StopCircle className="w-4 h-4" /> Stop Sequence
            </button>
          )}

          {(sequence.status === 'Failed' || sequence.status === 'Stopped') && (
            <button
              onClick={handleResumeSequence}
              disabled={actionLoading === 'resume'}
              className="px-4 py-2 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-600/40 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-lg shadow-emerald-950/50"
            >
              <Play className="w-4 h-4 fill-emerald-400" />
              {actionLoading === 'resume' ? 'Resuming...' : 'Resume Sequence'}
            </button>
          )}
        </div>
      </div>

      {/* Sequence Info Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-8 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColors[sequence.status] || ''}`}>
                {sequence.status}
              </span>
              <span className="text-xs text-slate-400">
                Mode: <strong className="text-slate-200 capitalize">{sequence.mode}</strong>
              </span>
              <span className="text-xs text-slate-400">
                Market: <strong className="text-slate-200">{sequence.market}</strong>
              </span>
              <span className="text-xs text-slate-400">
                Category: <strong className="text-slate-200">{sequence.category}</strong>
              </span>
            </div>
            <h1 className="text-xl font-bold text-white mb-1">{sequence.subject}</h1>
            <p className="text-sm text-slate-400">
              Recipient: <span className="text-white font-mono">{sequence.recipient}</span>
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Sender: <span className="text-emerald-400 font-mono">{sequence.sender_email}</span>
            </p>
          </div>

          <div className="text-left sm:text-right text-xs text-slate-400 space-y-1">
            {sequence.gmail_thread_id && (
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800 font-mono">
                <span className="text-slate-500 block text-[10px]">GMAIL CONVERSATION THREAD</span>
                <span className="text-blue-400">{sequence.gmail_thread_id}</span>
              </div>
            )}
            <div>Created: {new Date(sequence.created_at).toLocaleDateString()}</div>
          </div>
        </div>

        {sequence.status === 'Replied' && (
          <div className="mt-4 p-3 bg-indigo-500/10 border border-indigo-500/30 rounded-lg text-xs text-indigo-300 flex items-center gap-2">
            <Check className="w-4 h-4 text-indigo-400 flex-shrink-0" />
            <span><strong>Recipient replied!</strong> Automated follow-ups have been cancelled. The conversation thread is active.</span>
          </div>
        )}
      </div>

      {/* Sequential Message Timeline */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-400">
            Sequential Message Thread
          </h2>

          {sequence.status === 'Active' && (
            <button
              onClick={() => setShowAddModal(true)}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 transition"
            >
              Add Follow-up
            </button>
          )}
        </div>

        <div className="relative pl-6 border-l-2 border-slate-800 space-y-8">
          {sequence.messages.map((msg: Message, idx: number) => {
            const isInitial = msg.type === 'initial';
            const isEditing = editingMessageId === msg.id;

            return (
              <div key={msg.id} className="relative group">
                {/* Node indicator */}
                <div className={`absolute -left-[31px] top-1.5 w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                  msg.status === 'Sent'
                    ? 'bg-emerald-500 border-emerald-400 text-white'
                    : msg.status === 'Failed'
                    ? 'bg-rose-500 border-rose-400 text-white'
                    : msg.status === 'Skipped' || msg.status === 'Cancelled'
                    ? 'bg-slate-700 border-slate-600'
                    : 'bg-slate-900 border-blue-500'
                }`} />

                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">
                        {isInitial ? 'Initial Email' : `Follow-up #${msg.position - 1}`}
                      </span>
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${
                        msg.status === 'Sent'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : msg.status === 'Failed'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : msg.status === 'Scheduled'
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                          : msg.status === 'Sending'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                          : 'bg-slate-800 text-slate-400'
                      }`}>
                        {msg.status}
                      </span>
                    </div>

                    {/* Action buttons for unsent messages */}
                    {msg.status !== 'Sent' && sequence.status !== 'Replied' && (
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {/* Reorder (follow-ups only) */}
                        {!isInitial && (
                          <div className="flex items-center mr-1">
                            <button
                              disabled={idx <= 1}
                              onClick={() => handleMove(idx, 'up')}
                              className="p-1 text-slate-500 hover:text-white disabled:opacity-30"
                              title="Move Up"
                            >
                              ↑
                            </button>
                            <button
                              disabled={idx === sequence.messages.length - 1}
                              onClick={() => handleMove(idx, 'down')}
                              className="p-1 text-slate-500 hover:text-white disabled:opacity-30"
                              title="Move Down"
                            >
                              ↓
                            </button>
                          </div>
                        )}

                        <button
                          onClick={() => {
                            setEditingMessageId(msg.id);
                            setEditBody(msg.body);
                            const d = new Date(msg.scheduled_at);
                            setEditDate(d.toISOString().split('T')[0]);
                            setEditTime(d.toTimeString().substring(0, 5));
                          }}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" /> Edit
                        </button>

                        <button
                          onClick={() => handleSkip(msg.id)}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs flex items-center gap-1"
                        >
                          <SkipForward className="w-3 h-3" /> Skip
                        </button>

                        {!isInitial && (
                          <button
                            onClick={() => handleDeleteMessage(msg.id)}
                            className="p-1 rounded text-slate-500 hover:text-rose-400"
                            title="Delete Follow-up"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          onClick={() => handleSendNow(msg.id)}
                          disabled={actionLoading === msg.id}
                          className={`px-3 py-1 rounded text-white text-xs font-semibold flex items-center gap-1 shadow transition cursor-pointer ${
                            msg.status === 'Failed' 
                              ? 'bg-amber-600 hover:bg-amber-500 shadow-amber-900/40' 
                              : 'bg-blue-600 hover:bg-blue-500 shadow-blue-900/40'
                          }`}
                        >
                          {msg.status === 'Failed' ? <RotateCcw className="w-3 h-3" /> : <Send className="w-3 h-3" />}
                          {actionLoading === msg.id ? 'Sending...' : msg.status === 'Failed' ? 'Retry Now' : 'Send Now'}
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Schedule details */}
                  <div className="text-xs text-slate-400 mb-3 flex flex-wrap items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      {msg.status === 'Sent' ? (
                        <>Sent at: <strong className="text-white">{msg.sent_at ? new Date(msg.sent_at).toLocaleString() : 'Done'}</strong></>
                      ) : (
                        <>Scheduled: <strong className="text-white">{new Date(msg.scheduled_at).toLocaleString()}</strong> ({msg.timezone})</>
                      )}
                    </span>

                    {msg.rfc_message_id && (
                      <span className="font-mono text-[11px] text-slate-500 truncate max-w-xs" title={msg.rfc_message_id}>
                        RFC: {msg.rfc_message_id}
                      </span>
                    )}
                  </div>

                  {/* Error display if failed */}
                  {msg.error && (
                    <div className="p-3 mb-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-400 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                      <div>
                        <strong>Send Failed:</strong> {msg.error}
                        <p className="mt-1 text-slate-400">Subsequent messages remain blocked until this issue is resolved.</p>
                      </div>
                    </div>
                  )}

                  {/* Body Content or Edit Form */}
                  {isEditing ? (
                    <div className="mt-3 p-3 bg-slate-950 rounded-lg border border-slate-700 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-[11px] text-slate-400 block mb-1">Date</label>
                          <input
                            type="date"
                            value={editDate}
                            onChange={e => setEditDate(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-xs text-white"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] text-slate-400 block mb-1">Time</label>
                          <input
                            type="time"
                            value={editTime}
                            onChange={e => setEditTime(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-xs text-white"
                          />
                        </div>
                      </div>

                      <textarea
                        rows={4}
                        value={editBody}
                        onChange={e => setEditBody(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                      />

                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingMessageId(null)}
                          className="px-3 py-1 text-xs text-slate-400 hover:text-white"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(msg.id)}
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold"
                        >
                          Save Changes
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="text-xs text-slate-300 whitespace-pre-line bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
                        {msg.body}
                      </div>

                      {/* Attached Live Signature Preview */}
                      <div className="p-3 bg-slate-950/40 border border-slate-800/60 rounded-lg">
                        <div className="text-[10px] font-semibold tracking-wider uppercase text-slate-400 mb-2 flex items-center justify-between">
                          <span className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            Attached Gmail Signature (Live Preview)
                          </span>
                          <span className="text-[10px] font-normal text-slate-500 font-mono">
                            Auto-appended on dispatch
                          </span>
                        </div>
                        <div className="bg-white rounded-md p-3 text-slate-900 border border-slate-200 overflow-x-auto shadow-sm">
                          {sequence.signature_html ? (
                            <div dangerouslySetInnerHTML={{ __html: sequence.signature_html }} />
                          ) : (
                            <div className="text-xs text-slate-500 font-sans">
                              <strong>Sujal Bhatti</strong> • Visuals Creations
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal to add follow-up */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-lg w-full shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-4">Add Follow-up (Same Thread)</h3>
            
            <form onSubmit={handleAddFollowup} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Scheduled Date</label>
                  <input
                    type="date"
                    required
                    value={newDate}
                    onChange={e => setNewDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Scheduled Time</label>
                  <input
                    type="time"
                    required
                    value={newTime}
                    onChange={e => setNewTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Message Body</label>
                <textarea
                  rows={4}
                  required
                  value={newBody}
                  onChange={e => setNewBody(e.target.value)}
                  placeholder="Follow-up reply body..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  This will be queued as a sequential reply inside Gmail conversation thread.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionLoading === 'add'}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold"
                >
                  Add Follow-up
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
