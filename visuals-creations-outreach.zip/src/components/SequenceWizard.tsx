import React, { useState, useEffect } from 'react';
import { parseOutreachDocument, splitMultiProspectDocument, convertToUtcIso, formatTo12Hour, normalizeTimeTo24Hour, ParsedBlock } from '../utils/parser';
import { saveSequencesToVault, loadSequencesFromVault } from '../utils/vault';
import { getAccessToken, ensureFreshToken } from '../auth';
import {
  ArrowLeft,
  Plus,
  Trash2,
  Calendar,
  Clock,
  Globe,
  Send,
  FileText,
  CheckCircle2,
  Sparkles,
  Mail,
  AlertCircle
} from 'lucide-react';

interface Props {
  senderEmail: string;
  onCancel: () => void;
  onSequenceCreated: (seqId: string) => void;
}

export const SequenceWizard: React.FC<Props> = ({ senderEmail, onCancel, onSequenceCreated }) => {
  const defaultTz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Kolkata';

  // Common sequence meta
  const [recipient, setRecipient] = useState('');
  const [subject, setSubject] = useState('');
  const [market, setMarket] = useState('Creative / E-commerce');
  const [category, setCategory] = useState('Outreach');

  // Input raw paste text - auto-restored from draft if available
  const [rawText, setRawText] = useState(() => {
    const savedDraft = localStorage.getItem('outreach_wizard_draft_raw');
    if (savedDraft && savedDraft.trim()) {
      return savedDraft;
    }
    const todayStr = new Date().toISOString().split('T')[0];
    const d1 = new Date(); d1.setDate(d1.getDate() + 2);
    const d2 = new Date(); d2.setDate(d2.getDate() + 5);
    return `Recipient: prospect@example.com
Subject: Quick question regarding your creative assets

Initial Outreach
Date: ${todayStr}
Time: 4:30 PM
Timezone: ${defaultTz}

Hi John,

Saw you switched Gryt to a revenue share model only getting paid when the brand makes money. Loved that alignment.

Would love to share how our team produces creative assets for high-growth brands.

Follow-up 1
Date: ${d1.toISOString().split('T')[0]}
Time: 11:00 AM
Timezone: ${defaultTz}

Hi John,

Just bumping this quickly in case it got buried in your inbox.

Let me know if you have 5 minutes this week.

Follow-up 2
Date: ${d2.toISOString().split('T')[0]}
Time: 3:00 PM
Timezone: ${defaultTz}

Hi John,

Sharing a quick sample of our video editing work: visualscreations.com

Would this be relevant for you this quarter?`;
  });

  // Editable parsed blocks
  const [blocks, setBlocks] = useState<ParsedBlock[]>(() => {
    const parsed = parseOutreachDocument(rawText, defaultTz);
    return parsed.blocks;
  });

  const [hasParsed, setHasParsed] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [signatureHtml, setSignatureHtml] = useState<string | null>(null);
  const [batchItems, setBatchItems] = useState<Array<{ recipient: string; subject: string; blocks: ParsedBlock[] }> | null>(null);

  useEffect(() => {
    fetch('/api/auth/session')
      .then(res => res.json())
      .then(data => {
        if (data.signature) {
          setSignatureHtml(data.signature);
        }
      })
      .catch(() => {});
  }, []);

  // Trigger document parse (Supports both single sequence & multi-lead batch documents)
  const handleParseDocument = (customText?: string) => {
    const textToParse = customText !== undefined ? customText : rawText;
    if (!textToParse.trim()) {
      setError('Please paste your outreach document first.');
      return;
    }
    setError(null);

    const parts = splitMultiProspectDocument(textToParse);
    if (parts.length > 1) {
      const parsedItems = parts.map((part, idx) => {
        const p = parseOutreachDocument(part, defaultTz);
        return {
          recipient: p.recipient || `lead${idx + 1}@example.com`,
          subject: p.subject || subject || 'Creative Production Collaboration',
          blocks: p.blocks
        };
      });
      setBatchItems(parsedItems);
      const first = parsedItems[0];
      setRecipient(first.recipient);
      setSubject(first.subject);
      setBlocks(first.blocks);
      setHasParsed(true);
      return;
    }

    setBatchItems(null);
    const parsed = parseOutreachDocument(textToParse, defaultTz);

    if (parsed.recipient && !recipient) {
      setRecipient(parsed.recipient);
    }
    if (parsed.subject && !subject) {
      setSubject(parsed.subject);
    }

    setBlocks(parsed.blocks);
    setHasParsed(true);
  };

  // Block modification functions
  const updateBlock = (id: string, updates: Partial<ParsedBlock>) => {
    setBlocks(prev => prev.map(b => (b.id === id ? { ...b, ...updates } : b)));
  };

  const removeBlock = (id: string) => {
    setBlocks(prev => {
      const remaining = prev.filter(b => b.id !== id);
      // Re-index remaining
      return remaining.map((b, idx) => ({
        ...b,
        type: idx === 0 ? 'initial' : 'followup',
        title: idx === 0 ? 'INITIAL OUTREACH' : `FOLLOW-UP ${idx}`
      }));
    });
  };

  const addBlock = () => {
    const lastBlock = blocks[blocks.length - 1];
    let nextDate = new Date().toISOString().split('T')[0];
    if (lastBlock?.date) {
      const d = new Date(lastBlock.date);
      d.setDate(d.getDate() + 3);
      nextDate = d.toISOString().split('T')[0];
    }

    const newIdx = blocks.length;
    setBlocks(prev => [
      ...prev,
      {
        id: 'block_' + Date.now(),
        type: newIdx === 0 ? 'initial' : 'followup',
        title: newIdx === 0 ? 'INITIAL OUTREACH' : `FOLLOW-UP ${newIdx}`,
        body: '',
        date: nextDate,
        time: '10:00',
        timezone: lastBlock?.timezone || defaultTz
      }
    ]);
  };

  // Submit sequence
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const finalRecipient = recipient.trim();
    if (!finalRecipient || !finalRecipient.includes('@')) {
      setError('Please enter a valid recipient email address.');
      return;
    }

    if (blocks.length === 0) {
      setError('Please import or add at least one outreach email block.');
      return;
    }

    const firstBlock = blocks[0];
    const finalSubject = (subject || firstBlock.subject || '').trim();
    if (!finalSubject) {
      setError('Subject is required for the initial email. Please provide a subject.');
      return;
    }

    for (let i = 0; i < blocks.length; i++) {
      const b = blocks[i];
      if (!b.body.trim()) {
        setError(`Block "${b.title}" is empty. Please enter an email body or remove it.`);
        return;
      }
      if (!b.date || !b.time) {
        setError(`Block "${b.title}" is missing date or time.`);
        return;
      }
    }

    setLoading(true);

    try {
      // Build messages array
      const messagesPayload = blocks.map((b, idx) => {
        const utcIso = convertToUtcIso(b.date, b.time, b.timezone);
        return {
          position: idx + 1,
          type: idx === 0 ? 'initial' : 'followup',
          body: b.body,
          scheduled_at: utcIso,
          timezone: b.timezone,
          status: 'Scheduled'
        };
      });

      const token = await ensureFreshToken();

      // If batch import with multiple prospects detected
      if (batchItems && batchItems.length > 1) {
        const payloadItems = batchItems.map(item => ({
          sequence: {
            recipient: item.recipient,
            subject: item.subject || finalSubject,
            market,
            category,
            mode: 'auto',
            status: 'Active',
            sender_email: senderEmail
          },
          messages: item.blocks.map((b, idx) => ({
            position: idx + 1,
            type: idx === 0 ? 'initial' : 'followup',
            body: b.body,
            scheduled_at: convertToUtcIso(b.date, b.time, b.timezone),
            timezone: b.timezone,
            status: 'Scheduled'
          }))
        }));

        const res = await fetch('/api/sequences/batch', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {})
          },
          body: JSON.stringify({ items: payloadItems })
        });

        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.error || 'Failed to create batch sequences');
        }

        const data = await res.json();
        localStorage.removeItem('outreach_wizard_draft_raw');
        if (data.sequences && data.sequences.length > 0) {
          const currentVault = loadSequencesFromVault();
          saveSequencesToVault([...data.sequences, ...currentVault]);
          onSequenceCreated(data.sequences[0].id);
        } else {
          onCancel();
        }
        return;
      }

      const res = await fetch('/api/sequences', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          sequence: {
            recipient: finalRecipient,
            subject: finalSubject,
            market,
            category,
            mode: 'auto',
            status: 'Active',
            sender_email: senderEmail
          },
          messages: messagesPayload
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Failed to create sequence');
      }

      const created = await res.json();
      localStorage.removeItem('outreach_wizard_draft_raw');
      const currentVault = loadSequencesFromVault();
      saveSequencesToVault([created, ...currentVault]);
      onSequenceCreated(created.id);
    } catch (err: any) {
      setError(err.message || 'Something went wrong while creating the sequence.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <button
        onClick={onCancel}
        className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 text-sm font-medium transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </button>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 sm:p-8 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6 mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white tracking-tight">Outreach Document Importer & Sequencer</h2>
            <p className="text-sm text-slate-400 mt-1">
              Sender: <span className="text-emerald-400 font-mono font-medium">{senderEmail}</span>
            </p>
          </div>
          <div className="text-right">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Same-Thread Gmail Follow-ups
            </span>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 text-sm flex items-start gap-3">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>{error}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* STEP 1: PASTE DOCUMENT */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <label className="text-sm font-bold text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-400" />
                  Paste Complete Outreach Document
                </label>
                <p className="text-xs text-slate-400 mt-0.5">
                  Paste your full outreach text. The sequencer splits it into Initial and Follow-up blocks with their dates & times.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const todayStr = new Date().toISOString().split('T')[0];
                    const d1 = new Date(); d1.setDate(d1.getDate() + 2);
                    const d2 = new Date(); d2.setDate(d2.getDate() + 5);
                    const tmpl = `Recipient: prospect@example.com
Subject: Quick question regarding your creative assets

Initial Outreach
Date: ${todayStr}
Time: 4:30 PM
Timezone: ${defaultTz}

Hi John,

Saw you switched Gryt to a revenue share model only getting paid when the brand makes money. Loved that alignment.

Would love to share how our team produces creative assets for high-growth brands.

Follow-up 1
Date: ${d1.toISOString().split('T')[0]}
Time: 11:00 AM
Timezone: ${defaultTz}

Hi John,

Just bumping this quickly in case it got buried in your inbox.

Let me know if you have 5 minutes this week.

Follow-up 2
Date: ${d2.toISOString().split('T')[0]}
Time: 3:00 PM
Timezone: ${defaultTz}

Hi John,

Sharing a quick sample of our video editing work: visualscreations.com

Would this be relevant for you this quarter?`;
                    setRawText(tmpl);
                    handleParseDocument(tmpl);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 transition cursor-pointer"
                >
                  Load Template
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setRawText('');
                    localStorage.removeItem('outreach_wizard_draft_raw');
                    setBlocks([]);
                  }}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded-lg text-xs border border-slate-800 transition cursor-pointer"
                  title="Clear text"
                >
                  Clear
                </button>
                <button
                  type="button"
                  onClick={() => handleParseDocument()}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow transition cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" /> Re-parse
                </button>
              </div>
            </div>

            <textarea
              rows={8}
              value={rawText}
              onChange={e => {
                const val = e.target.value;
                setRawText(val);
                localStorage.setItem('outreach_wizard_draft_raw', val);
                // Dynamically re-parse so user immediately sees blocks
                handleParseDocument(val);
              }}
              placeholder="Paste complete outreach sequence here..."
              className="w-full font-mono text-xs bg-slate-900 border border-slate-700 rounded-lg p-3.5 text-slate-200 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* SEQUENCE METADATA */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Recipient Email *
              </label>
              <input
                type="email"
                required
                placeholder="prospect@company.com"
                value={recipient}
                onChange={e => setRecipient(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Thread Subject *
              </label>
              <input
                type="text"
                required
                placeholder="Partnership inquiry"
                value={subject}
                onChange={e => setSubject(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Market
              </label>
              <input
                type="text"
                value={market}
                onChange={e => setMarket(e.target.value)}
                placeholder="e.g. US Tech, Creative Agencies"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Category
              </label>
              <input
                type="text"
                value={category}
                onChange={e => setCategory(e.target.value)}
                placeholder="e.g. Outreach, Cold Email"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-sm"
              />
            </div>
          </div>

          {/* STEP 2: EDITABLE BLOCKS SEPARATED */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Mail className="w-4 h-4 text-blue-400" />
                  Detected Outreach Blocks ({blocks.length})
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Each block is editable. Follow-ups send automatically as replies within the initial email's Gmail thread.
                </p>
              </div>

              <button
                type="button"
                onClick={addBlock}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-blue-300 rounded text-xs font-medium border border-slate-700 transition"
              >
                <Plus className="w-3.5 h-3.5" /> Add Follow-up Block
              </button>
            </div>

            {blocks.length === 0 ? (
              <div className="p-8 text-center border border-dashed border-slate-800 rounded-xl text-slate-500 text-sm">
                No blocks found yet. Paste your document above to split automatically.
              </div>
            ) : (
              <div className="space-y-5">
                {blocks.map((block, idx) => {
                  const isInitial = idx === 0;
                  const utcIso = convertToUtcIso(block.date, block.time, block.timezone);
                  const displayLocalScheduled = new Date(utcIso).toLocaleString();

                  return (
                    <div
                      key={block.id}
                      className={`border rounded-xl p-5 transition-all shadow-sm ${
                        isInitial
                          ? 'bg-slate-900/90 border-blue-500/40 ring-1 ring-blue-500/20'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {/* Block Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 border-b border-slate-800/80 pb-3">
                        <div className="flex items-center gap-2.5">
                          <span
                            className={`px-2.5 py-1 rounded text-xs font-bold tracking-wider uppercase ${
                              isInitial
                                ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                : 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                            }`}
                          >
                            {isInitial ? 'INITIAL OUTREACH' : `FOLLOW-UP ${idx}`}
                          </span>
                          <span className="text-xs text-slate-400 font-medium">
                            {isInitial ? '(Creates Gmail Thread)' : '(Same Thread Reply)'}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
                            <Clock className="w-3.5 h-3.5 text-blue-400" />
                            <span>
                              Scheduled: <strong className="text-slate-200">{block.date} at {formatTo12Hour(block.time) || block.time}</strong> <span className="text-slate-500">({block.timezone})</span>
                            </span>
                          </div>

                          {!isInitial && (
                            <button
                              type="button"
                              onClick={() => removeBlock(block.id)}
                              className="text-slate-500 hover:text-rose-400 p-1 transition"
                              title="Delete this block"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Schedule Controls for this Block */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4 bg-slate-950 p-3 rounded-lg border border-slate-800/70 text-xs">
                        <div>
                          <label className="block text-slate-400 mb-1 font-medium flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" /> Date
                          </label>
                          <input
                            type="date"
                            required
                            value={block.date}
                            onChange={e => updateBlock(block.id, { date: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-slate-400 font-medium flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 text-slate-400" /> Time
                            </label>
                            {block.time && (
                              <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 px-1.5 py-0.2 rounded border border-blue-500/20 font-bold">
                                {formatTo12Hour(block.time)}
                              </span>
                            )}
                          </div>
                          <input
                            type="time"
                            required
                            value={normalizeTimeTo24Hour(block.time) || block.time}
                            onChange={e => updateBlock(block.id, { time: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-blue-500 font-mono"
                          />
                        </div>

                        <div>
                          <label className="block text-slate-400 mb-1 font-medium flex items-center gap-1">
                            <Globe className="w-3.5 h-3.5 text-slate-400" /> Timezone
                          </label>
                          <input
                            type="text"
                            required
                            value={block.timezone}
                            onChange={e => updateBlock(block.id, { timezone: e.target.value })}
                            placeholder="e.g. Asia/Kolkata, America/New_York"
                            className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>
                      </div>

                      {/* Block Body Textarea */}
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                          Email Content *
                        </label>
                        <textarea
                          rows={isInitial ? 5 : 3}
                          required
                          value={block.body}
                          onChange={e => updateBlock(block.id, { body: e.target.value })}
                          placeholder="Email message content..."
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-sans"
                        />

                        {/* Live Signature Preview */}
                        <div className="mt-2.5 p-2.5 bg-slate-950/50 border border-slate-800 rounded-lg">
                          <div className="text-[10px] font-semibold tracking-wider uppercase text-slate-400 mb-1.5 flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                              Attached Signature (Auto-Appended)
                            </span>
                            <span className="text-[10px] font-normal text-slate-500 font-mono">visualscreations.com</span>
                          </div>
                          <div className="bg-white rounded p-2.5 text-slate-900 border border-slate-200 overflow-x-auto shadow-sm">
                            {signatureHtml ? (
                              <div dangerouslySetInnerHTML={{ __html: signatureHtml }} />
                            ) : (
                              <div className="text-xs text-slate-600 font-sans">
                                <strong>Sujal Bhatti</strong> • Founder &amp; Creative Director | Visuals Creations
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* BATCH IMPORT NOTICE IF DETECTED */}
          {batchItems && batchItems.length > 1 && (
            <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-200 text-xs flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong className="text-emerald-300">Multi-Lead Batch Import Detected:</strong> {batchItems.length} individual prospects found in your pasted text. Submitting will create and schedule all {batchItems.length} separate outreach threads automatically.
                </span>
              </div>
              <span className="px-2.5 py-1 rounded bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-mono font-bold text-xs shrink-0">
                {batchItems.length} Sequences
              </span>
            </div>
          )}

          {/* SUBMIT BUTTON */}
          <div className="flex items-center justify-end gap-3 pt-6 border-t border-slate-800">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-300 text-sm font-medium transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || blocks.length === 0}
              className="px-6 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium flex items-center gap-2 shadow-lg shadow-blue-600/20 transition disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              {loading 
                ? 'Creating Sequences...' 
                : (batchItems && batchItems.length > 1 
                    ? `Create & Schedule All ${batchItems.length} Sequences` 
                    : `Create & Schedule Sequence (${blocks.length} Steps)`)}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
