import { initializeApp, getApps } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User, signOut } from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);

const STORAGE_KEY_TOKEN = 'gmail_access_token';
const STORAGE_KEY_EMAIL = 'gmail_sender_email';
const STORAGE_KEY_SAVED_AT = 'gmail_token_saved_at';

// Scopes required for Gmail operations
const GMAIL_SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.settings.basic'
].join(' ');

let isSigningIn = false;
let isSilentRefreshing = false;
let cachedAccessToken: string | null = null;
let cachedActiveEmail: string | null = null;
let tokenSavedAt: number = 0;
let gisTokenClient: any = null;
let heartbeatIntervalId: any = null;

// Subscribers for auth state updates
const authSuccessListeners: Array<(email: string, token: string) => void> = [];
const authFailureListeners: Array<() => void> = [];
const tokenExpiredListeners: Array<(email: string) => void> = [];

export interface SignInOptions {
  switchAccount?: boolean;
  targetEmail?: string;
}

/**
 * Initialize Google Identity Services (GIS) token client for silent background renewals
 */
const initGisClient = (): Promise<boolean> => {
  return new Promise((resolve) => {
    if (typeof window === 'undefined') return resolve(false);

    const checkGis = () => {
      const google = (window as any).google;
      if (google?.accounts?.oauth2?.initTokenClient && firebaseConfig.oAuthClientId) {
        try {
          gisTokenClient = google.accounts.oauth2.initTokenClient({
            client_id: firebaseConfig.oAuthClientId,
            scope: GMAIL_SCOPES,
            callback: async (tokenResponse: any) => {
              if (tokenResponse?.access_token) {
                console.log('[Auth] GIS silent token refresh succeeded.');
                const email = cachedActiveEmail || localStorage.getItem(STORAGE_KEY_EMAIL) || '';
                await handleNewToken(tokenResponse.access_token, email);
              }
            },
            error_callback: (err: any) => {
              console.warn('[Auth] GIS silent token refresh error:', err);
            }
          });
          resolve(true);
          return true;
        } catch (e) {
          console.warn('[Auth] Error initializing GIS client:', e);
          resolve(false);
          return true;
        }
      }
      return false;
    };

    if (!checkGis()) {
      let attempts = 0;
      const interval = setInterval(() => {
        attempts++;
        if (checkGis() || attempts > 20) {
          clearInterval(interval);
          resolve(Boolean(gisTokenClient));
        }
      }, 250);
    }
  });
};

/**
 * Request a silent background access token refresh without any popup or user interaction
 */
export const requestSilentTokenRefresh = async (hintEmail?: string): Promise<string | null> => {
  if (isSilentRefreshing) return cachedAccessToken;
  isSilentRefreshing = true;

  try {
    const targetEmail = hintEmail || cachedActiveEmail || localStorage.getItem(STORAGE_KEY_EMAIL) || '';

    // Strategy 1: Google Identity Services with prompt: '' (completely silent iframe)
    if (!gisTokenClient) {
      await initGisClient();
    }

    if (gisTokenClient) {
      const tokenPromise = new Promise<string | null>((resolve) => {
        const timeout = setTimeout(() => {
          resolve(null);
        }, 6000);

        gisTokenClient.callback = async (tokenResponse: any) => {
          clearTimeout(timeout);
          if (tokenResponse?.access_token) {
            await handleNewToken(tokenResponse.access_token, targetEmail);
            resolve(tokenResponse.access_token);
          } else {
            resolve(null);
          }
        };

        try {
          gisTokenClient.requestAccessToken({
            prompt: '', // Silent request
            hint: targetEmail || undefined
          });
        } catch (err) {
          clearTimeout(timeout);
          resolve(null);
        }
      });

      const result = await tokenPromise;
      if (result) {
        console.log('[Auth] Successfully refreshed token silently via GIS.');
        return result;
      }
    }

    // Strategy 2: If GIS silent request did not return a token, check server session
    const serverSession = await checkServerSession();
    if (serverSession?.token) {
      return serverSession.token;
    }

    return null;
  } catch (err) {
    console.warn('[Auth] Silent token refresh encountered error:', err);
    return null;
  } finally {
    isSilentRefreshing = false;
  }
};

/**
 * Handle new token arrival: store in memory, localStorage, and sync to backend DB
 */
const handleNewToken = async (token: string, email: string, displayName?: string) => {
  cachedAccessToken = token;
  tokenSavedAt = Date.now();
  localStorage.setItem(STORAGE_KEY_TOKEN, token);
  localStorage.setItem(STORAGE_KEY_SAVED_AT, tokenSavedAt.toString());

  if (email) {
    cachedActiveEmail = email.toLowerCase().trim();
    localStorage.setItem(STORAGE_KEY_EMAIL, cachedActiveEmail);
  }

  // Sync token to server database so background scheduler has it immediately
  try {
    await fetch('/api/auth/sync-token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({
        email: cachedActiveEmail || email,
        accessToken: token,
        displayName: displayName || (cachedActiveEmail ? cachedActiveEmail.split('@')[0] : undefined)
      })
    });
  } catch (e) {
    console.warn('[Auth] Failed to sync refreshed token to server:', e);
  }

  // Notify listeners
  authSuccessListeners.forEach(cb => cb(cachedActiveEmail || email, token));
};

/**
 * Ensures the access token is fresh before any critical API or sending action.
 * If the token is older than 40 minutes, silently renews it.
 */
export const ensureFreshToken = async (): Promise<string | null> => {
  const now = Date.now();
  const savedAtStr = localStorage.getItem(STORAGE_KEY_SAVED_AT);
  const savedAt = savedAtStr ? parseInt(savedAtStr, 10) : tokenSavedAt;
  const tokenAgeMs = now - savedAt;

  // Google OAuth tokens expire in 60 minutes (3,600,000 ms).
  // If token is less than 40 minutes old (2,400,000 ms) and we have it in memory, return it.
  if (cachedAccessToken && tokenAgeMs < 40 * 60 * 1000) {
    return cachedAccessToken;
  }

  // Otherwise, renew silently
  console.log('[Auth] Token is over 40 minutes old or missing from memory. Renewing silently...');
  const refreshed = await requestSilentTokenRefresh();
  if (refreshed) {
    return refreshed;
  }

  return cachedAccessToken || localStorage.getItem(STORAGE_KEY_TOKEN);
};

/**
 * Check backend database session
 */
const checkServerSession = async () => {
  try {
    const res = await fetch('/api/auth/session');
    if (!res.ok) return null;
    const data = await res.json();
    if (data.connected && data.token && data.email) {
      cachedAccessToken = data.token;
      cachedActiveEmail = data.email.toLowerCase().trim();
      tokenSavedAt = Date.now();
      localStorage.setItem(STORAGE_KEY_TOKEN, data.token);
      localStorage.setItem(STORAGE_KEY_EMAIL, data.email);
      localStorage.setItem(STORAGE_KEY_SAVED_AT, tokenSavedAt.toString());
      return data;
    }
    return data;
  } catch (e) {
    return null;
  }
};

/**
 * Setup proactive background heartbeat and tab visibility listeners
 */
const startProactiveRenewalHeartbeat = () => {
  if (heartbeatIntervalId) clearInterval(heartbeatIntervalId);

  // Heartbeat every 30 minutes while tab is active
  heartbeatIntervalId = setInterval(async () => {
    if (cachedActiveEmail || localStorage.getItem(STORAGE_KEY_EMAIL)) {
      console.log('[Auth] Proactive 30-min heartbeat: renewing Google access token silently...');
      await requestSilentTokenRefresh();
    }
  }, 30 * 60 * 1000);

  // Visibility and focus listeners: renew if tab was backgrounded for more than 40 mins
  if (typeof window !== 'undefined') {
    const onVisibilityOrFocus = async () => {
      if (document.visibilityState === 'visible') {
        const savedAtStr = localStorage.getItem(STORAGE_KEY_SAVED_AT);
        const savedAt = savedAtStr ? parseInt(savedAtStr, 10) : 0;
        if (Date.now() - savedAt > 40 * 60 * 1000) {
          console.log('[Auth] Tab focused after inactivity: refreshing Google token silently...');
          await requestSilentTokenRefresh();
        }
      }
    };

    window.addEventListener('focus', onVisibilityOrFocus);
    document.addEventListener('visibilitychange', onVisibilityOrFocus);
  }
};

/**
 * Main authentication initialization called on app mount
 */
export const initAuth = (
  onAuthSuccess?: (email: string, token: string) => void,
  onAuthFailure?: () => void,
  onTokenExpired?: (email: string) => void
) => {
  if (onAuthSuccess) authSuccessListeners.push(onAuthSuccess);
  if (onAuthFailure) authFailureListeners.push(onAuthFailure);
  if (onTokenExpired) tokenExpiredListeners.push(onTokenExpired);

  // Initialize GIS client in the background
  initGisClient();
  startProactiveRenewalHeartbeat();

  const restoreSession = async () => {
    // 1. Check server DB session first
    const sessionData = await checkServerSession();

    if (sessionData?.connected && sessionData.email && sessionData.token) {
      authSuccessListeners.forEach(cb => cb(sessionData.email, sessionData.token));
      return;
    }

    const storedToken = localStorage.getItem(STORAGE_KEY_TOKEN);
    const storedEmail = localStorage.getItem(STORAGE_KEY_EMAIL);

    if (storedEmail) {
      cachedActiveEmail = storedEmail;

      // Try silent background refresh first before ever declaring session expired!
      console.log('[Auth] Existing sender found in storage. Attempting silent token renewal...');
      const silentToken = await requestSilentTokenRefresh(storedEmail);
      if (silentToken) {
        authSuccessListeners.forEach(cb => cb(storedEmail, silentToken));
        return;
      }

      // If stored token is still valid on server
      if (storedToken) {
        try {
          const testRes = await fetch('/api/sender/info', {
            headers: { Authorization: `Bearer ${storedToken}` }
          });
          if (testRes.ok) {
            cachedAccessToken = storedToken;
            authSuccessListeners.forEach(cb => cb(storedEmail, storedToken));
            return;
          }
        } catch (e) {
          // ignore
        }
      }

      // Only if silent renewal could not be performed, notify listeners with stored email
      authSuccessListeners.forEach(cb => cb(storedEmail, storedToken || ''));
      return;
    }

    // No existing session
    authFailureListeners.forEach(cb => cb());
  };

  // Run restoration immediately
  restoreSession();

  // Listen to Firebase auth state
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      const email = user.email || cachedActiveEmail || '';
      if (email) {
        cachedActiveEmail = email;
        const token = cachedAccessToken || localStorage.getItem(STORAGE_KEY_TOKEN);
        if (token) {
          authSuccessListeners.forEach(cb => cb(email, token));
        } else {
          // Silently request access token
          requestSilentTokenRefresh(email);
        }
      }
    }
  });
};

/**
 * Interactive Google Sign-In with popup
 */
export const googleSignIn = async (options?: SignInOptions): Promise<{ user: User; accessToken: string; email: string } | null> => {
  try {
    isSigningIn = true;
    const provider = new GoogleAuthProvider();
    provider.addScope('https://www.googleapis.com/auth/gmail.send');
    provider.addScope('https://www.googleapis.com/auth/gmail.modify');
    provider.addScope('https://www.googleapis.com/auth/gmail.readonly');
    provider.addScope('https://www.googleapis.com/auth/gmail.settings.basic');

    const customParams: Record<string, string> = {
      access_type: 'offline'
    };

    if (options?.switchAccount) {
      customParams.prompt = 'select_account consent';
    } else {
      customParams.prompt = 'consent';
      if (options?.targetEmail) {
        customParams.login_hint = options.targetEmail;
      }
    }

    provider.setCustomParameters(customParams);

    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token from Google Sign-in');
    }

    const token = credential.accessToken;
    const email = (result.user.email || options?.targetEmail || '').toLowerCase().trim();

    await handleNewToken(token, email, result.user.displayName || undefined);

    return { user: result.user, accessToken: token, email };
  } catch (error: any) {
    console.error('Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = (): string | null => {
  return cachedAccessToken || localStorage.getItem(STORAGE_KEY_TOKEN);
};

export const getSavedEmail = (): string => {
  return cachedActiveEmail || localStorage.getItem(STORAGE_KEY_EMAIL) || '';
};

export const logout = async () => {
  const email = cachedActiveEmail || localStorage.getItem(STORAGE_KEY_EMAIL);
  try {
    await signOut(auth);
  } catch (e) {}
  cachedAccessToken = null;
  cachedActiveEmail = null;
  tokenSavedAt = 0;
  localStorage.removeItem(STORAGE_KEY_TOKEN);
  localStorage.removeItem(STORAGE_KEY_EMAIL);
  localStorage.removeItem(STORAGE_KEY_SAVED_AT);
  if (email) {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
    } catch (e) {}
  }
  authFailureListeners.forEach(cb => cb());
};

/**
 * Transparent authenticated fetch wrapper:
 * Automatically includes the fresh access token, and on 401 response silently renews and retries.
 */
export const authenticatedFetch = async (url: string, init: RequestInit = {}): Promise<Response> => {
  let token = await ensureFreshToken();

  const headers = new Headers(init.headers || {});
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  let res = await fetch(url, { ...init, headers });

  // If 401 Unauthorized, automatically renew token silently and retry once
  if (res.status === 401) {
    console.log('[Auth] 401 received from API. Attempting silent token renewal & auto-retry...');
    const freshToken = await requestSilentTokenRefresh();
    if (freshToken) {
      const retryHeaders = new Headers(init.headers || {});
      retryHeaders.set('Authorization', `Bearer ${freshToken}`);
      res = await fetch(url, { ...init, headers: retryHeaders });
    }
  }

  return res;
};
