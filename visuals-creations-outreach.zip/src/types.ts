export type SequenceStatus = 'Active' | 'Replied' | 'Stopped' | 'Completed' | 'Failed';

export type MessageStatus = 'Draft' | 'Scheduled' | 'Sending' | 'Sent' | 'Skipped' | 'Cancelled' | 'Failed';

export type MessageType = 'initial' | 'followup';

export type ConnectionMode = 'oauth' | 'app_password';

export interface GmailConnection {
  id: string; // e.g. "conn_xxx"
  user_id: string;
  gmail_email: string;
  sender_display_name?: string;
  access_token: string;
  refresh_token?: string;
  token_expiry?: number; // ms timestamp
  granted_scopes: string[];
  signature_html?: string;
  connected_at: string;
  updated_at: string;
  connection_mode?: ConnectionMode;
  app_password?: string;
  oauth_client_id?: string;
  oauth_client_secret?: string;
}

export interface Sequence {
  id: string;
  user_id?: string;
  gmail_connection_id?: string;
  recipient: string;
  subject: string;
  original_subject: string;
  market?: string;
  category?: string;
  mode?: 'manual' | 'auto';
  status: SequenceStatus;
  sender_email: string;
  gmail_thread_id?: string | null;
  signature_html?: string;
  created_at: string;
  updated_at: string;
}

export interface MessageAuthDiagnostics {
  spf?: string;
  dkim?: string;
  dmarc?: string;
  raw_auth_results?: string;
  smtp_response?: string;
  checked_at?: string;
}

export interface Message {
  id: string;
  sequence_id: string;
  position: number; // 1 = initial, 2 = followup 1, 3 = followup 2...
  type: MessageType;
  body: string;
  scheduled_at: string; // ISO 8601 string
  scheduled_at_utc: string;
  timezone: string;
  status: MessageStatus;
  gmail_message_id?: string | null;
  rfc_message_id?: string | null;
  in_reply_to?: string | null;
  references?: string | null;
  sent_at?: string | null;
  error?: string | null;
  auth_diagnostics?: MessageAuthDiagnostics | null;
  created_at: string;
  updated_at: string;
}

export interface SequenceWithMessages extends Sequence {
  messages: Message[];
}

export interface SchedulerRunResult {
  processed: number;
  sent: number;
  replied: number;
  errors: Array<{ messageId?: string; sequenceId?: string; error: string }>;
  timestamp: string;
}
