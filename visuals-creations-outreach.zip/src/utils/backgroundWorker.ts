/**
 * Web Worker-based background ticker.
 * Standard `setInterval` in browser tabs is throttled by Chrome/Safari to 1 tick per minute
 * when the tab is hidden/minimized. Web Workers run on a separate thread and are NOT throttled,
 * allowing uninterrupted background dispatching of scheduled sequences.
 */

let workerInstance: Worker | null = null;

export function startBackgroundScheduler(onTick: () => void, intervalMs: number = 15000): () => void {
  // Inline worker blob to avoid separate file serving issues
  const workerBlob = new Blob(
    [
      `
      let timer = null;
      self.onmessage = function(e) {
        if (e.data === 'start') {
          if (timer) clearInterval(timer);
          timer = setInterval(function() {
            self.postMessage('tick');
          }, ${intervalMs});
        } else if (e.data === 'stop') {
          if (timer) clearInterval(timer);
          timer = null;
        }
      };
    `
    ],
    { type: 'application/javascript' }
  );

  const workerUrl = URL.createObjectURL(workerBlob);
  try {
    workerInstance = new Worker(workerUrl);
    workerInstance.onmessage = (e) => {
      if (e.data === 'tick') {
        onTick();
      }
    };
    workerInstance.postMessage('start');
  } catch (err) {
    console.warn('[BackgroundWorker] Fallback to standard interval:', err);
    const id = setInterval(onTick, intervalMs);
    return () => clearInterval(id);
  }

  return () => {
    if (workerInstance) {
      workerInstance.postMessage('stop');
      workerInstance.terminate();
      workerInstance = null;
    }
    URL.revokeObjectURL(workerUrl);
  };
}
