import { SequenceWithMessages } from '../types';
import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, doc, setDoc, getDocs, collection } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const VAULT_KEY = 'outreach_vault_sequences_v1';
const VAULT_TIMESTAMP_KEY = 'outreach_vault_last_saved';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
const firestoreDb = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

/**
 * Saves all sequences to both the browser's persistent localStorage vault
 * AND to the persistent Google Cloud Firestore database.
 * This guarantees survival across container restarts, browser reloads, and computer shutdowns.
 */
export function saveSequencesToVault(sequences: SequenceWithMessages[]): void {
  try {
    if (!sequences || !Array.isArray(sequences)) return;
    localStorage.setItem(VAULT_KEY, JSON.stringify(sequences));
    localStorage.setItem(VAULT_TIMESTAMP_KEY, new Date().toISOString());

    // Asynchronously push to persistent Cloud Firestore
    sequences.forEach(seq => {
      if (seq && seq.id) {
        setDoc(doc(firestoreDb, 'sequences', seq.id), seq, { merge: true }).catch(() => {});
      }
    });
  } catch (err) {
    console.warn('[Vault] Failed to save sequences to localStorage:', err);
  }
}

/**
 * Loads all saved sequences from the browser vault, falling back to Firestore if available.
 */
export function loadSequencesFromVault(): SequenceWithMessages[] {
  try {
    const raw = localStorage.getItem(VAULT_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('[Vault] Failed to load sequences from localStorage:', err);
  }
  return [];
}

/**
 * Synchronizes the local browser vault and Firestore cloud with the backend server database.
 * If the server was rebooted/reset (common in ephemeral cloud containers),
 * this automatically re-pushes the local vault to the server so zero data is lost.
 */
export async function syncVaultWithServer(
  serverSequences: SequenceWithMessages[]
): Promise<SequenceWithMessages[]> {
  let localVault = loadSequencesFromVault();

  // If local vault in localStorage was empty, attempt reading from Cloud Firestore
  if (localVault.length === 0) {
    try {
      const snap = await getDocs(collection(firestoreDb, 'sequences'));
      const cloudSeqs: SequenceWithMessages[] = [];
      snap.forEach(d => {
        cloudSeqs.push(d.data() as SequenceWithMessages);
      });
      if (cloudSeqs.length > 0) {
        localVault = cloudSeqs;
        saveSequencesToVault(cloudSeqs);
      }
    } catch {
      // Offline or network error
    }
  }

  // If local vault is still empty, populate it from the server
  if (localVault.length === 0) {
    if (serverSequences && serverSequences.length > 0) {
      saveSequencesToVault(serverSequences);
    }
    return serverSequences;
  }

  // Check if server is missing sequences that are in the local/cloud vault
  const serverIds = new Set(serverSequences.map(s => s.id));
  const missingOnServer = localVault.filter(s => !serverIds.has(s.id));

  if (missingOnServer.length > 0) {
    console.log(`[Vault] Detected ${missingOnServer.length} sequences in vault missing from server. Auto-restoring...`);
    try {
      const res = await fetch('/api/sequences/restore-vault', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sequences: missingOnServer })
      });
      if (res.ok) {
        const data = await res.json();
        console.log(`[Vault] Successfully auto-restored ${data.restoredCount || missingOnServer.length} sequences to server.`);
        if (data.allSequences && Array.isArray(data.allSequences)) {
          saveSequencesToVault(data.allSequences);
          return data.allSequences;
        }
      }
    } catch (err) {
      console.warn('[Vault] Error restoring sequences to server:', err);
    }
  }

  // Merge server and local
  const combinedMap = new Map<string, SequenceWithMessages>();
  localVault.forEach(s => combinedMap.set(s.id, s));
  serverSequences.forEach(s => combinedMap.set(s.id, s)); // Server has freshest sent timestamps
  const merged = Array.from(combinedMap.values());
  saveSequencesToVault(merged);
  return merged;
}

/**
 * Downloads a complete JSON backup file of all sequences and messages to the user's computer
 */
export function exportVaultToFile(sequences: SequenceWithMessages[]): void {
  try {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(sequences, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    const dateStr = new Date().toISOString().split('T')[0];
    downloadAnchor.setAttribute('download', `visuals_creations_sequences_backup_${dateStr}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  } catch (err) {
    console.error('[Vault] Failed to export backup file:', err);
  }
}
