/**
 * Outreach document parser and timezone utilities.
 * Handles ANY document structure:
 * - "Initial Outreach", "Initial Email", "Day 0 — Initial", "Email 1", "Step 1"
 * - "Follow-up 1", "Followup 2", "Follow up 3", "Day 3 — Follow-up", "Email 2"
 * - Robust automatic detection of date, time, timezone, recipient, and subject
 * - Normalizes time into 24-hour HH:mm for HTML time inputs while supporting 12-hour AM/PM formats
 */

export interface ParsedBlock {
  id: string;
  type: 'initial' | 'followup';
  title: string;
  subject?: string;
  body: string;
  date: string;
  time: string;
  timezone: string;
}

export interface ParsedOutreachDoc {
  recipient?: string;
  subject?: string;
  blocks: ParsedBlock[];
}

export const TIMEZONE_ALIASES: Record<string, string> = {
  IST: 'Asia/Kolkata',
  INDIA: 'Asia/Kolkata',
  EST: 'America/New_York',
  EDT: 'America/New_York',
  ET: 'America/New_York',
  CST: 'America/Chicago',
  CDT: 'America/Chicago',
  CT: 'America/Chicago',
  MST: 'America/Denver',
  MDT: 'America/Denver',
  MT: 'America/Denver',
  PST: 'America/Los_Angeles',
  PDT: 'America/Los_Angeles',
  PT: 'America/Los_Angeles',
  GMT: 'UTC',
  UTC: 'UTC',
  BST: 'Europe/London',
  CET: 'Europe/Paris',
  CEST: 'Europe/Paris',
  AEST: 'Australia/Sydney',
  AEDT: 'Australia/Sydney',
  SGT: 'Asia/Singapore',
  JST: 'Asia/Tokyo',
  KST: 'Asia/Seoul',
  HKT: 'Asia/Hong_Kong',
  GST: 'Asia/Dubai',
  DUBAI: 'Asia/Dubai'
};

/**
 * Validates a timezone name supported by Intl
 */
export function isValidTimeZone(tz: string): boolean {
  if (!tz || !tz.trim()) return false;
  try {
    Intl.DateTimeFormat(undefined, { timeZone: tz.trim() });
    return true;
  } catch {
    return false;
  }
}

/**
 * Resolves standard timezone abbreviations (like IST, EST, UTC) into valid IANA timezone names
 */
export function resolveTimezone(tz: string): string | null {
  if (!tz) return null;
  const clean = tz.trim().replace(/[()[\],]/g, '').toUpperCase();
  if (TIMEZONE_ALIASES[clean]) {
    return TIMEZONE_ALIASES[clean];
  }
  if (isValidTimeZone(tz.trim())) {
    return tz.trim();
  }
  return null;
}

/**
 * Normalizes any time representation into 24-hour HH:mm string.
 * Examples:
 * - "10:00 AM" -> "10:00"
 * - "4:30 PM"  -> "16:30"
 * - "4:30pm"   -> "16:30"
 * - "4pm"      -> "16:00"
 * - "10am"     -> "10:00"
 * - "16:30"    -> "16:30"
 * - "16.30"    -> "16:30"
 * - "4.30 PM"  -> "16:30"
 * - "12:00 PM" -> "12:00"
 * - "12:00 AM" -> "00:00"
 * - "12pm"     -> "12:00"
 * - "12am"     -> "00:00"
 */
export function normalizeTimeTo24Hour(timeStr: string): string | null {
  if (!timeStr) return null;
  const clean = timeStr.trim();

  // 1. HH:MM or H:MM with optional colon or dot, optional AM/PM
  const matchColon = clean.match(/\b([01]?\d|2[0-3])[:.]([0-5]\d)(?::[0-5]\d)?\s*(am|pm)?\b/i);
  if (matchColon) {
    let hour = parseInt(matchColon[1], 10);
    const minute = parseInt(matchColon[2], 10);
    const ampm = matchColon[3]?.toUpperCase();

    if (ampm === 'PM' && hour < 12) hour += 12;
    if (ampm === 'AM' && hour === 12) hour = 0;

    const pad = (n: number) => (n < 10 ? '0' + n : '' + n);
    return `${pad(hour)}:${pad(minute)}`;
  }

  // 2. Hour only with AM/PM (e.g. "4pm", "10am", "11 AM")
  const matchHourOnly = clean.match(/\b([01]?\d)\s*(am|pm)\b/i);
  if (matchHourOnly) {
    let hour = parseInt(matchHourOnly[1], 10);
    const ampm = matchHourOnly[2].toUpperCase();

    if (ampm === 'PM' && hour < 12) hour += 12;
    if (ampm === 'AM' && hour === 12) hour = 0;

    const pad = (n: number) => (n < 10 ? '0' + n : '' + n);
    return `${pad(hour)}:00`;
  }

  return null;
}

/**
 * Formats 24-hour time HH:mm into friendly 12-hour AM/PM string (e.g. "16:30" -> "4:30 PM")
 */
export function formatTo12Hour(time24: string): string {
  if (!time24) return '';
  const match = time24.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
  if (!match) return time24;
  let h = parseInt(match[1], 10);
  const m = match[2];
  const ampm = h >= 12 ? 'PM' : 'AM';
  if (h === 0) h = 12;
  else if (h > 12) h -= 12;
  return `${h}:${m} ${ampm}`;
}

/**
 * Normalizes date into YYYY-MM-DD format for HTML date inputs.
 */
export function normalizeDate(dateStr: string): string | null {
  if (!dateStr) return null;
  const clean = dateStr.trim();

  // 1. ISO YYYY-MM-DD or YYYY/MM/DD
  const isoMatch = clean.match(/\b([12]\d{3})[-/](0?[1-9]|1[0-2])[-/](0?[1-9]|[12]\d|3[01])\b/);
  if (isoMatch) {
    const pad = (n: string) => (n.length === 1 ? '0' + n : n);
    return `${isoMatch[1]}-${pad(isoMatch[2])}-${pad(isoMatch[3])}`;
  }

  // 2. DD-MM-YYYY or DD/MM/YYYY
  const dmyMatch = clean.match(/\b(0?[1-9]|[12]\d|3[01])[-/](0?[1-9]|1[0-2])[-/]([12]\d{3})\b/);
  if (dmyMatch) {
    const pad = (n: string) => (n.length === 1 ? '0' + n : n);
    return `${dmyMatch[3]}-${pad(dmyMatch[2])}-${pad(dmyMatch[1])}`;
  }

  // 3. Named month: e.g. "Sep 30, 2026", "September 30 2026", "30 Sept 2026"
  const stripped = clean.replace(/^(?:Date|Send|Schedule|Scheduled)\s*[:—\-–=]\s*/i, '');
  const parsed = new Date(stripped);
  if (!isNaN(parsed.getTime())) {
    const pad = (n: number) => (n < 10 ? '0' + n : '' + n);
    const y = parsed.getFullYear();
    const m = pad(parsed.getMonth() + 1);
    const d = pad(parsed.getDate());
    return `${y}-${m}-${d}`;
  }

  return null;
}

/**
 * Extracts timezone from any line containing a timezone abbreviation or name
 */
export function extractTimezoneFromString(str: string): string | null {
  if (!str) return null;
  const words = str.split(/[\s,()[\]:]+/);
  for (const w of words) {
    if (['AM', 'PM', 'TIME', 'DATE', 'AT', 'SEND', 'SCHEDULE', 'SCHEDULED', 'TO', 'BY'].includes(w.toUpperCase())) continue;
    const resolved = resolveTimezone(w);
    if (resolved) return resolved;
  }
  return null;
}

/**
 * Converts local date, time, and timezone accurately to UTC ISO string.
 */
export function convertToUtcIso(dateStr: string, timeStr: string, timeZone: string = 'UTC'): string {
  try {
    const cleanDate = normalizeDate(dateStr) || (dateStr || '').trim();
    const cleanTime = normalizeTimeTo24Hour(timeStr) || '10:00';
    const [hours, minutes] = cleanTime.split(':').map(n => parseInt(n, 10));

    const pad = (n: number) => (n < 10 ? '0' + n : '' + n);
    const naiveUtc = new Date(`${cleanDate}T${pad(hours)}:${pad(minutes)}:00.000Z`);

    if (isNaN(naiveUtc.getTime())) {
      const fallback = new Date();
      fallback.setMinutes(fallback.getMinutes() + 10);
      return fallback.toISOString();
    }

    const tzToUse = timeZone && isValidTimeZone(timeZone) ? timeZone.trim() : 'UTC';

    const inv = new Date(naiveUtc.toLocaleString('en-US', { timeZone: 'UTC' }));
    const target = new Date(naiveUtc.toLocaleString('en-US', { timeZone: tzToUse }));
    const offsetDiffMs = target.getTime() - inv.getTime();

    const finalUtc = new Date(naiveUtc.getTime() - offsetDiffMs);
    return finalUtc.toISOString();
  } catch (err) {
    console.warn('Error converting to UTC ISO:', err);
    const fallback = new Date();
    fallback.setMinutes(fallback.getMinutes() + 10);
    return fallback.toISOString();
  }
}

/**
 * Parses any outreach document by identifying section headers and metadata.
 */
export function parseOutreachDocument(
  text: string,
  fallbackTimezone: string = 'America/New_York'
): ParsedOutreachDoc {
  const result: ParsedOutreachDoc = {
    blocks: []
  };

  if (!text || !text.trim()) return result;

  const defaultTz = isValidTimeZone(fallbackTimezone)
    ? fallbackTimezone
    : Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/New_York';

  // 1. Look for top-level Recipient / To:
  const recipientMatch = text.match(/(?:^|\n)\s*(?:Recipient|To)\s*[:—\-–=]\s*([^\r\n]+@[^\r\n]+)/i);
  if (recipientMatch) {
    result.recipient = recipientMatch[1].trim();
  }

  // 2. Identify all section boundary headers.
  const headerRegex = /(?:^|\n)(?:#+\s*)?((?:Initial\s*(?:Outreach|Email|Message|Follow-?up)?)|(?:Follow[-\s]*up(?:\s*\d+)?)|(?:Day\s*\d+\s*[—\-–:]*\s*(?:Initial(?:\s*Email)?|Follow[-\s]*up(?:\s*\d+)?|Email\s*\d+)?)|(?:Email\s*\d+)|(?:Step\s*\d+))(?:\s*[:—\-–\n]|\s*$)/gi;

  const matches: { index: number; title: string; fullMatchLength: number }[] = [];
  let m: RegExpExecArray | null;

  while ((m = headerRegex.exec(text)) !== null) {
    matches.push({
      index: m.index,
      title: m[1].trim(),
      fullMatchLength: m[0].length
    });
  }

  const rawSections: { title: string; content: string }[] = [];

  if (matches.length === 0) {
    // Single document without headers -> 1 initial outreach block
    rawSections.push({
      title: 'INITIAL OUTREACH',
      content: text.trim()
    });
  } else {
    for (let i = 0; i < matches.length; i++) {
      const current = matches[i];
      const next = matches[i + 1];
      const startIdx = current.index + current.fullMatchLength;
      const endIdx = next ? next.index : text.length;
      const sectionContent = text.substring(startIdx, endIdx).trim();

      rawSections.push({
        title: current.title,
        content: sectionContent
      });
    }
  }

  rawSections.forEach((sec, idx) => {
    const isInitial = idx === 0 || /initial|email\s*1|^step\s*1/i.test(sec.title);
    const standardTitle = isInitial
      ? 'INITIAL OUTREACH'
      : (sec.title.toUpperCase().includes('FOLLOW')
          ? sec.title.toUpperCase()
          : `FOLLOW-UP ${idx}`);

    const lines = sec.content.split('\n');
    const bodyLines: string[] = [];

    let sectionSubject: string | undefined;
    let dateStr: string | undefined;
    let timeStr: string | undefined;
    let tzStr: string | undefined;

    // Check if the section header itself contained date, time, or timezone
    const titleTime = normalizeTimeTo24Hour(sec.title);
    if (titleTime) timeStr = titleTime;
    const titleDate = normalizeDate(sec.title);
    if (titleDate) dateStr = titleDate;
    const titleTz = extractTimezoneFromString(sec.title);
    if (titleTz) tzStr = titleTz;

    for (const rawLine of lines) {
      const trimmed = rawLine.trim();

      // Skip empty lines in metadata phase
      if (!trimmed) {
        if (bodyLines.length > 0) {
          bodyLines.push(rawLine);
        }
        continue;
      }

      // 1. Recipient check
      const recMatch = trimmed.match(/^(?:Recipient|To)\s*[:—\-–=]\s*([^\r\n]+@[^\r\n]+)/i);
      if (recMatch) {
        if (!result.recipient) result.recipient = recMatch[1].trim();
        continue;
      }

      // 2. Subject check
      const subjMatch = trimmed.match(/^Subject\s*[:—\-–=]\s*(.+)$/i);
      if (subjMatch) {
        sectionSubject = subjMatch[1].trim();
        if (!result.subject) result.subject = sectionSubject;
        continue;
      }

      // 3. Combined Schedule / Send At / Date & Time check
      // e.g. "Schedule: 2026-09-30 at 4:30 PM EST" or "Date & Time: 2026-09-30 16:30"
      const isScheduleLine = /^(?:Schedule|Scheduled|Send\s*At|Date\s*(&|and)?\s*Time)\s*[:—\-–=]/i.test(trimmed);
      if (isScheduleLine) {
        const detectedDate = normalizeDate(trimmed);
        if (detectedDate) dateStr = detectedDate;

        const detectedTime = normalizeTimeTo24Hour(trimmed);
        if (detectedTime) timeStr = detectedTime;

        const detectedTz = extractTimezoneFromString(trimmed);
        if (detectedTz) tzStr = detectedTz;
        continue;
      }

      // 4. Date line check
      // e.g. "Date: 2026-09-30", "Date: Sep 30, 2026", "Send Date: 2026-10-02"
      const isDateLine = /^(?:Date|Send\s*Date)\s*[:—\-–=]/i.test(trimmed);
      if (isDateLine) {
        const detectedDate = normalizeDate(trimmed);
        if (detectedDate) dateStr = detectedDate;

        // Also check if time was appended to the date line: e.g. "Date: 2026-09-30 at 10:00 AM"
        const detectedTime = normalizeTimeTo24Hour(trimmed);
        if (detectedTime && !timeStr) timeStr = detectedTime;

        const detectedTz = extractTimezoneFromString(trimmed);
        if (detectedTz && !tzStr) tzStr = detectedTz;
        continue;
      }

      // 5. Time line check
      // e.g. "Time: 10:00 AM", "Time: 4:30 PM IST", "Time: 16:30", "Time - 4pm"
      const isExplicitTimeLine = /^(?:Time|Send\s*Time|At)\s*[:—\-–=]/i.test(trimmed);
      if (isExplicitTimeLine) {
        const detectedTime = normalizeTimeTo24Hour(trimmed);
        if (detectedTime) timeStr = detectedTime;

        // Check if timezone was specified on the same line: "Time: 10:00 AM IST"
        const detectedTz = extractTimezoneFromString(trimmed);
        if (detectedTz) tzStr = detectedTz;
        continue;
      }

      // 6. Timezone line check
      // e.g. "Timezone: Asia/Kolkata", "TZ: EST", "Time Zone: America/New_York"
      const isTzLine = /^(?:Timezone|Time\s*Zone|TZ)\s*[:—\-–=]/i.test(trimmed);
      if (isTzLine) {
        const cleanTz = trimmed.replace(/^(?:Timezone|Time\s*Zone|TZ)\s*[:—\-–=]\s*/i, '');
        const resolved = resolveTimezone(cleanTz) || extractTimezoneFromString(cleanTz);
        if (resolved) tzStr = resolved;
        continue;
      }

      // 7. Explicit Body tag
      const bodyTag = trimmed.match(/^Body\s*[:—\-–=]\s*(.*)$/i);
      if (bodyTag) {
        if (bodyTag[1].trim()) {
          bodyLines.push(bodyTag[1].trim());
        }
        continue;
      }

      // 8. Standalone time or date line before body begins
      // If we don't have a time yet, and the line is purely a time expression (e.g. "10:00 AM", "4:30 PM IST", "16:30")
      if (!timeStr && bodyLines.length === 0) {
        const standaloneTime = normalizeTimeTo24Hour(trimmed);
        if (standaloneTime && trimmed.length <= 25) {
          timeStr = standaloneTime;
          const detectedTz = extractTimezoneFromString(trimmed);
          if (detectedTz && !tzStr) tzStr = detectedTz;
          continue;
        }
      }

      // Otherwise this line belongs to the email body
      bodyLines.push(rawLine);
    }

    // Default dates if omitted:
    let finalDate = dateStr;
    let finalTime = timeStr;
    const finalTz = (tzStr && isValidTimeZone(tzStr)) ? tzStr : defaultTz;

    if (!finalDate) {
      const d = new Date();
      d.setDate(d.getDate() + (idx * 3));
      finalDate = d.toISOString().split('T')[0];
    }

    if (!finalTime) {
      finalTime = '10:00';
    }

    result.blocks.push({
      id: 'block_' + idx + '_' + Date.now(),
      type: isInitial ? 'initial' : 'followup',
      title: standardTitle,
      subject: sectionSubject,
      body: bodyLines.join('\n').trim(),
      date: finalDate,
      time: finalTime,
      timezone: finalTz
    });
  });

  return result;
}

/**
 * Splits a pasted document containing multiple prospects into separate prospect documents.
 * Recognizes multiple "Recipient:" or "To:" headers and divides the text into individual sequences.
 */
export function splitMultiProspectDocument(text: string): string[] {
  if (!text || !text.trim()) return [];
  const regex = /(?:^|\n)(?=(?:Recipient|To)\s*[:—\-–=]\s*[^\r\n]+@[^\r\n]+)/gi;
  const parts = text.split(regex).map(p => p.trim()).filter(Boolean);
  return parts.length > 0 ? parts : [text.trim()];
}
