import { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { SequenceWizard } from './components/SequenceWizard';
import { SequenceDetail } from './components/SequenceDetail';
import { initAuth } from './auth';

export default function App() {
  const [view, setView] = useState<'dashboard' | 'wizard' | 'detail'>('dashboard');
  const [selectedSequenceId, setSelectedSequenceId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [tokenExpired, setTokenExpired] = useState(false);

  useEffect(() => {
    initAuth(
      (email, _token) => {
        setUserEmail(email);
        setTokenExpired(false);
      },
      () => {
        setUserEmail(null);
        setTokenExpired(false);
      },
      (email) => {
        setUserEmail(email);
        setTokenExpired(true);
      }
    );
  }, []);

  const handleSequenceCreated = (id: string) => {
    setSelectedSequenceId(id);
    setView('detail');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-blue-600 selection:text-white">
      {view === 'dashboard' && (
        <Dashboard
          onCreateClick={() => setView('wizard')}
          onSelectSequence={(id) => {
            setSelectedSequenceId(id);
            setView('detail');
          }}
          userEmail={userEmail}
          tokenExpired={tokenExpired}
          onAuthChange={(email, expired = false) => {
            setUserEmail(email);
            setTokenExpired(expired);
          }}
        />
      )}

      {view === 'wizard' && (
        <SequenceWizard
          senderEmail={userEmail || ''}
          onCancel={() => setView('dashboard')}
          onSequenceCreated={handleSequenceCreated}
        />
      )}

      {view === 'detail' && selectedSequenceId && (
        <SequenceDetail
          sequenceId={selectedSequenceId}
          onBack={() => setView('dashboard')}
          onRefresh={() => {}}
        />
      )}
    </div>
  );
}
